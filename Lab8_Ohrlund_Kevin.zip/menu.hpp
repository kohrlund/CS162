/**********************************************************************************************************************
**Program name: SortSearch
**Author: Kevin J. Ohrlund
**Date: 23 May 2018
**Description: Header file for the menu class. Contains function definitions for all functions that run the program.
************************************************************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

#include <iostream>
#include <fstream>
#include <limits>
#include <vector>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::string;
using std::vector;

class Menu
{
public:
	Menu();
	void run();
	int validate(int x, int y);
	void copyToVector(ifstream &file, string fileName, vector<int> &numberVector);
	void printVector(vector<int> &numberVector, string vectorName);
	void simpleSearch(vector<int> &numberVector, string vectorName, int searchNumber);
	void simpleSort(vector<int> &numberVector);
	void binarySearch(vector<int> &numberVector, string vectorName, int searchNumber);
	void popVector(vector<int> &vectors);
	~Menu();

private:
	int menuChoice, vectorInput;
	ifstream num, early, mid, end;
	string numFile, earlyFile, midFile, endFile;
	vector<int> numVector;
	vector<int> earlyVector;
	vector<int> midVector;
	vector<int> endVector;
};

#endif
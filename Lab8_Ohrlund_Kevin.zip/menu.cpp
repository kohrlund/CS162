/*******************************************************************************************************
**Program name: SortSearch
**Author: Kevin J. Ohrlund
**Date: 23 May 2018
**Description: Implementation file for the menu class. Defines the searching and sorting algorithms.
********************************************************************************************************/

#include "menu.hpp"

Menu::Menu()
{

}

//Controls the flow of the program and runs the menu options.
void Menu::run()
{
	cout << "Welcome to the simple sort and search Lab!" << endl;
	cout << "Programmed by Kevin J. Ohrlund." << endl << endl;

	cout << "Enter your choice below:" << endl;
	cout << "1. Conduct a simple search." << endl;
	cout << "2. Conduct a simple sort." << endl;
	cout << "3. Conduct a binary search." << endl;
	cout << "4. Exit." << endl;

	menuChoice = validate(1, 4);

	//If the user chooses to start the program...
	if (menuChoice != 4)
	{
		//Create the text file names.
		numFile = "num.txt";
		earlyFile = "early.txt";
		midFile = "mid.txt";
		endFile = "end.txt";

		//Open and copy the values of the text file to the vectors.
		copyToVector(num, numFile, numVector);
		copyToVector(early, earlyFile, earlyVector);
		copyToVector(mid, midFile, midVector);
		copyToVector(end, endFile, endVector);

		//Display the vector as it was copied.
		cout << "\n\nThe original vectors copied from the file as follows:" << endl;
		printVector(numVector, numFile);
		printVector(earlyVector, earlyFile);
		printVector(midVector, midFile);
		printVector(endVector, endFile);

		cout << endl << endl;
	}

	//While the user continues to choose menu options...
	while (menuChoice != 4)
	{
		//Call the simple (linear) search function for each vector.
		if (menuChoice == 1)
		{
			cout << "Enter the value you would like to search for in each vector: ";
			menuChoice = validate(0, 10);

			simpleSearch(numVector, numFile, menuChoice);
			simpleSearch(earlyVector, earlyFile, menuChoice);
			simpleSearch(midVector, midFile, menuChoice);
			simpleSearch(endVector, endFile, menuChoice);
			cout << endl << endl;
		}

		//Call the simple (bubble) sort function for each vector.
		else if (menuChoice == 2)
		{
			simpleSort(numVector);
			simpleSort(earlyVector);
			simpleSort(midVector);
			simpleSort(endVector);

			//Display the sorted vectors.
			cout << "\n\nYour sorted vectors:" << endl;
			printVector(numVector, numFile);
			printVector(earlyVector, earlyFile);
			printVector(midVector, midFile);
			printVector(endVector, endFile);

			cout << endl << endl;
		}

		//Call the binary search function for each vector.
		else if (menuChoice == 3)
		{
			cout << "\n\nEnter the value you would like to search for: ";
			menuChoice = validate(0, 10);

			binarySearch(numVector, numFile, menuChoice);
			binarySearch(earlyVector, earlyFile, menuChoice);
			binarySearch(midVector, midFile, menuChoice);
			binarySearch(endVector, endFile, menuChoice);

			cout << endl << endl;
		}

		cout << "Enter your choice below:" << endl;
		cout << "1. Conduct a simple search." << endl;
		cout << "2. Conduct a simple sort." << endl;
		cout << "3. Conduct a binary search." << endl;
		cout << "4. Exit." << endl;

		menuChoice = validate(1, 4);
	}
}

//Helper function to validate user's input.
int Menu::validate(int x, int y)
{
	int z = 0;
	cin >> z;

	while (cin.fail() || z < x || z > y)
	{
		cout << "Invalid entry. Enter a number from " << x << " to " << y << '.' << endl;
		cin.clear();
		cin.ignore(std::numeric_limits<int>::max(), '\n');

		cin >> z;
	}

	return z;
}

//Called at the beginning of the program to fill the vectors with data from the specified files.
void Menu::copyToVector(ifstream &file, string fileName, vector<int> &numberVector)
{
	file.open(fileName);
	while (file >> vectorInput)
	{
		numberVector.push_back(vectorInput);
	}

	file.close();
}

//Helper function that prints the entire vector.
void Menu::printVector(vector<int> &numberVector, string vectorName)
{
	cout << vectorName << ": ";
	for (int i = 0; i < numberVector.size(); i++)
	{
		cout << numberVector[i] << " ";
	}

	cout << endl;
}


//Simple linear search algorithm. Starts at vector[0] and compares until no more items remain or it finds the search number.
void Menu::simpleSearch(vector<int> &numberVector, string vectorName, int searchNumber)
{
	bool hasNumber = false;
	for (int i = 0; i < numberVector.size(); i++)
	{
		if (numberVector[i] == searchNumber)
		{
			hasNumber = true;
			break;
		}
	}

	if (hasNumber == true)
	{
		cout << vectorName << " HAS the integer " << searchNumber << '.' << endl;
	}

	else
	{
		cout << vectorName << " does NOT have the integer " << searchNumber << '.' << endl;
	}
}

//Bubble search agorithm pseudocode used as a starting point:
//https://www.tutorialspoint.com/data_structures_algorithms/bubble_sort_algorithm.htm
void Menu::simpleSort(vector<int> &numberVector)
{
	int temp;
	bool hasSwapped;

	for (int i = 0; i < numberVector.size() - 1; i++)
	{
		hasSwapped = false;
		{
			for (int j = 0; j < numberVector.size() - i - 1; j++)
			{
				if (numberVector[j] > numberVector[j + 1])
				{
					temp = numberVector[j];
					numberVector[j] = numberVector[j + 1];
					numberVector[j + 1] = temp;
					hasSwapped = true;
				}
			}
			if (hasSwapped == false)
			{
				break;
			}
		}
	}

	//Prompts the user to specify the output file for the sorted vectors.
	string outFile;
	ofstream ofs;

	cout << "Please enter the name of the file you would like output this sorted vector to: ";
	cin >> outFile;
	ofs.open(outFile);

	for (int i = 0; i < numberVector.size(); i++)
	{
		ofs << numberVector[i] << ' ';
	}

	ofs << '\n';
	ofs.close();
}

void Menu::popVector(vector<int> &vectors)
{
	while (vectors.size() > 0)
	{
		vectors.pop_back();
	}
}

//Binary search algorithm. Adapted from the following website:
//https://medium.freecodecamp.org/what-is-binary-search-algorithm-c-d4b554418ac4
void Menu::binarySearch(vector<int> &numberVector, string vectorName, int searchNumber)
{
	bool hasNumber = false;
	int min = 0, max = numberVector.size() - 1, guess;
	
	while (min <= max)
	{
		guess = (int)(((max + min) / 2) + .5);

		if (searchNumber == numberVector[guess])
		{
			hasNumber = true;
			break;
		}

		else if (numberVector[guess] < searchNumber)
		{
			min = guess + 1;
		}

		else
		{
			max = guess - 1;
		}
	}

	if (hasNumber == true)
	{
		cout << vectorName << " HAS the number " << searchNumber << '.';
	}

	else
	{
		cout << vectorName << " does NOT have the number " << searchNumber << '.';
	}

	cout << endl;
}

Menu::~Menu()
{
	popVector(numVector);
	popVector(earlyVector);
	popVector(midVector);
	popVector(endVector);
}
/*******************************************************************************************************
**Program name: SortSearch
**Author: Kevin J. Ohrlund
**Date: 23 May 2018
**Description: Main function calls the start menu.
********************************************************************************************************/

#include "menu.hpp"

int main()
{
	Menu m1;
	m1.run();

	return 0;
}
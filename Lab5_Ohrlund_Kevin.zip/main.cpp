/*********************************************************************************
**Program Name: Recursive Functions
**Author: Kevin J. Ohrlund
**Date: 6 May 2018
**Description: Main function instantiates a menu object and begins the program.
**********************************************************************************/

#include <iostream>
#include "menu.hpp"

int main()
{
	Menu m1;
	m1.run();
	return 0;
}
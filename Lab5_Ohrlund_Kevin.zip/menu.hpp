/*********************************************************************************
**Program Name: Recursive Functions
**Author: Kevin J. Ohrlund
**Date: 6 May 2018
**Description: Header file for the menu class.
**********************************************************************************/

#ifndef	MENU_HPP
#define MENU_HPP
#include <iostream>
using std::string;

class Menu
{
public:
	void run();
	void reverseString(string userString);
	int calcSum(int *intArray, int size);
	int triangularNumber(int n);
	int validate(int x, int y);

private:
	string userString;
	int menuChoice, arraySize, triNumber;

};

#endif
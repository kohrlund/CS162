/*******************************************************************************************************************************
**Program Name: Recursive Functions
**Author: Kevin J. Ohrlund
**Date: 6 May 2018
**Description: Implementation file for the Menu class. Contains the functions of the program and runs the flow of the program.
********************************************************************************************************************************/

#include "menu.hpp"
#include <iostream>
#include <limits>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;


void Menu::run()
{
	//Greet the user.
	cout << "Welcome to the recursive functions exercise!" << endl;
	cout << "Programmed by Kevin J. Ohrlund." << endl << endl;

	menuChoice = 1;

	//Prompt the user for their choice and validate.
	while (menuChoice != 4)
	{
		cout << "\n\nEnter your choice for a recursive function below:" << endl;
		cout << "1. reverseString() - displays the reverse of a user-input string." << endl;
		cout << "2. calcSum() - calculates the sum of an array of integers." << endl;
		cout << "3. triangularNumber() - calculates the user's triangular number." << endl;
		cout << "4. Exit the program." << endl;

		menuChoice = validate(1, 4);

		//If the user chooses 1, run reverseString().
		if (menuChoice == 1)
		{
			cout << "Enter your string to be reversed:" << endl;
			cin.ignore();
			getline(cin, userString);

			cout << "\n\nYou entered: " << '"' << userString << '"' << endl;
			cout << "Reversed, it is: " << '"';
			reverseString(userString);
			cout << '"' << endl;
		}

		//If the user chooses 2, run calcSum();
		else if (menuChoice == 2)
		{
			//Prompt the user for their numbers and create the array.
			cout << "\nPlease enter the size of the array you would like to sum: ";
			arraySize = validate(1, 100);
			int *intArray = new int[arraySize];

			cout << "Please enter your " << arraySize << " integers." << endl;
			for (int i = 0; i < arraySize; i++)
			{
				cin >> intArray[i];
			}

			//Display the array the user entered.
			cout << "The array you entered is: ";
			for (int i = 0; i < arraySize; i++)
			{
				cout << intArray[i];
				if (i < arraySize - 1)
				{
					cout << ", ";
				}
			}

			//Display the sum.
			arraySize--;
			cout << "\nYour sum is: " << calcSum(intArray, arraySize);

			delete[]intArray;
		}

		//If the user chooses 3, run triangularNumber().
		else if (menuChoice == 3)
		{
			cout << "\n\nEnter a number, and I'll display its corresponding triangular number: ";
			cin >> triNumber;

			cout << "Your number: " << triNumber << endl;
			cout << "Its triangular number: " << triangularNumber(triNumber) << endl;
		}
	}
}

//Recursively displays the last character in a string.
void Menu::reverseString(string userString)
{
	if (userString.length() == 0)
	{
		return;
	}
	else
	{
		cout << userString.back();
		userString.pop_back();
		reverseString(userString);
	}
}

//Recursively calculates the sum of an array of integers.
int Menu::calcSum(int *intArray, int size)
{
	if (size == 0)
	{
		return intArray[0];
	}

	else
	{
		return intArray[size] + calcSum(intArray, size - 1);
	}
}

//Recursively calculates a triangular number for a given integer.
int Menu::triangularNumber(int n)
{
	if (n == 1)
	{
		return 1;
	}

	else
	{
		return n + triangularNumber(n - 1);
	}
}

//Helper function to validate input.
int Menu::validate(int x, int y)
{
	int z = 0;
	cin >> z;

	while (cin.fail() || z < x || z > y)
	{
		cout << "Invalid entry. Enter a number between " << x << " and " << y << '.' << endl;
		cin.clear();
		cin.ignore(std::numeric_limits<int>::max(), '\n');
		cin >> z;
	}

	return z;
}
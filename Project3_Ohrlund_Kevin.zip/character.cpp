/***********************************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Implementation file for the Character Class. Implements all functions that runs the program.
************************************************************************************************************/

#include "character.hpp"

//Default constructor for a Character object.
Character::Character()
{
	numOffDie = 0;
	numDefDie = 0;
	offDie = 0;
	defDie = 0;
	hitpoints = 0;
	defense = 0;
	rollResult = 0;
	type = "No type.";
	maxHealth = 0;
}

Character::~Character()
{

}
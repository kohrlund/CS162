/*******************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Header file for the Blue Men Class.
*******************************************************************************************/

#ifndef BLUEMEN
#define BLUEMEN
#include "barbarian.hpp"

class Bluemen : public Barbarian
{
public:
	Bluemen();
	int attack();
	int defend(int attack);
	void modifyHealth(int x);
	int getHealth();
	string getType();
	int getArmor();
	~Bluemen();

private:
	bool than8;
	bool than4;
};

#endif // !BLUEMEN
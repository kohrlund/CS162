/*******************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Header file for the Barbarian Class.
*******************************************************************************************/
#ifndef BARBARIAN_HPP
#define BARBARIAN_HPP
#include "character.hpp"

class Barbarian : public Character
{
public:
	Barbarian();
	int attack();
	int defend(int attack);
	void modifyHealth(int x);
	int getHealth();
	string getType();
	int getArmor();
	~Barbarian();

private:
};

#endif // !BARBARIAN_HPP
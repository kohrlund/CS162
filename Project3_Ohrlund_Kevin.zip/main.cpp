/***********************************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Main function. Seeds the rnadom number generator and runs the start menu.
************************************************************************************************************/

#include <ctime>
#include <cstdlib>
#include "menu.hpp"

int main()
{
	//Instantiate a menu object.
	Menu m1;

	//Seed the random number generator.
	srand(time(0));

	//Run the menu.
	m1.run();
	return 0;
}
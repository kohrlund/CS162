/*******************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Header file for the Medusa Class.
*******************************************************************************************/

#ifndef MEDUSA_HPP
#define MEDUSA_HPP
#include "barbarian.hpp"

class Medusa : public Character
{
public:
	Medusa();
	int attack();
	int defend(int attack);
	void modifyHealth(int x);
	int getHealth();
	string getType();
	int getArmor();
	~Medusa();

private:
	int specialAttack;
};

#endif
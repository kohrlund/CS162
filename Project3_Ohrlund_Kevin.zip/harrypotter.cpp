/***********************************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Implementation file for the Harry Potter Class. Implements all functions that runs the program.
************************************************************************************************************/

#include "harrypotter.hpp"
#include <iostream>

using std::cout;
using std::endl;

//Constructor for Harry's stats.
Harrypotter::Harrypotter()
{
	numOffDie = 2;
	numDefDie = 2;
	offDie = 6;
	defDie = 6;
	hitpoints = 10;
	defense = 3;
	maxHealth = 10;
	type = "Harry Potter";
	hasDied = false;
}

//Standard attack function.
int Harrypotter::attack()
{
	int counter = 0;
	for (int i = 0; i < numOffDie; i++)
	{
		rollResult = rand() % offDie + 1;
		cout << "Harry Potter attacks and rolls a " << rollResult << '.' << endl;
		counter += rollResult;
	}
	
	return counter;
}

//Standard defend function.
int Harrypotter::defend(int attack)
{
	int counter = 0;
	for (int i = 0; i < numDefDie; i++)
	{
		cout << "Harry Potter defends and rolls a ";
		rollResult = rand() % defDie + 1;
		cout << rollResult << '.' << endl;
		counter += rollResult;
	}

	return counter;
}

//Override for harry's special ability.
void Harrypotter::modifyHealth(int x)
{
	hitpoints -= x;

	//If harry hasn't died once yet, set his strength to 20 and set hasDied to true (so it doesn't run again).
	if (hasDied == false && hitpoints < 1)
	{
		hitpoints = 20;
		hasDied = true;
		cout << "Harry has died... but has been resurrected by 'Hogwarts', his special ability!" << endl;
		cout << "Harry's new maximum strength is 20." << endl;
	}
}

//Returns the amount of strength points a character has.
int Harrypotter::getHealth()
{
	return hitpoints;
}

//Returns the type of character the player is.
string Harrypotter::getType()
{
	return type;
}

//Returns the number of armor points the player has.
int Harrypotter::getArmor()
{
	return defense;
}

Harrypotter::~Harrypotter()
{

}
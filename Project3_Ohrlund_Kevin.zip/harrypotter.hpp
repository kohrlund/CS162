/*******************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Header file for the Harry Potter Class.
*******************************************************************************************/

#ifndef HARRYPOTTER_HPP
#define HARRYPOTTER_HPP
#include "character.hpp"

class Harrypotter : public Character
{
public:
	Harrypotter();
	int attack();
	int defend(int attack);
	void modifyHealth(int x);
	int getHealth();
	string getType();
	int getArmor();
	~Harrypotter();

private:
	bool hasDied;
};

#endif
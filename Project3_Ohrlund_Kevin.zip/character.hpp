/*******************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Header file for the Character Class (Base class for all other characters).
*******************************************************************************************/

#ifndef CHARACTER_HPP
#define CHARACTER_HPP

#include <cstdlib>
#include <string>
using std::string;

class Character
{
public:
	Character();
	int virtual attack() = 0;
	int virtual defend(int attack) = 0;
	void virtual modifyHealth(int x) = 0;
	int virtual getHealth() = 0;
	string virtual getType() = 0;
	int virtual getArmor() = 0;
	~Character();

private:

protected:
	int numRolls, hitpoints, defense, rollResult, offDie, defDie, maxHealth, damage, numOffDie, numDefDie;
	string type;
};

#endif
/***********************************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Implementation file for the Medusa Class. Implements all functions that runs the program.
************************************************************************************************************/

#include "medusa.hpp"
#include <iostream>

using std::cout;
using std::endl;

//Constructor for Medusa's stats.
Medusa::Medusa()
{
	numOffDie = 2;
	numDefDie = 1;
	offDie = 6;
	defDie = 6;
	hitpoints = 8;
	defense = 0;
	maxHealth = 8;
	type = "Medusa";
	specialAttack = 0;
}

//Override attack function for medusa's gaze special attack.
int Medusa::attack()
{
	specialAttack = 0;

	//Roll medusa's die.
	for (int i=0; i<numOffDie;i++)
	{
		rollResult = rand() % offDie + 1;
		cout << "Medusa attacks and rolls a " << rollResult << '.' << endl;
		specialAttack += rollResult;
	}
		//If she rolls a 12...
		if (specialAttack == 12)
		{
			cout << "Medusa has cast her Gaze, turning her opponent to stone and killing them instantly." << endl;
			return 100;
		}

		//Else return the attack value.
		else
		{
			return specialAttack;
		}
}
//Standard defend function.
int Medusa::defend(int attack)
{
	int counter = 0;

	for (int i = 0; i < numDefDie; i++)
	{
		cout << "Medusa defends and rolls a ";
		rollResult = rand() % defDie + 1;
		cout << rollResult << '.' << endl;
		counter += rollResult;
	}
	return counter;
}

//Returns the amount of strength points a character has.
int Medusa::getHealth()
{
	return hitpoints;
}

//Returns the type of character the player is.
string Medusa::getType()
{
	return type;
}

//Returns the number of armor points the player has.
int Medusa::getArmor()
{
	return defense;
}

//Function that modifies the damage based on the result of the round.
void Medusa::modifyHealth(int x)
{
	hitpoints -= x;
}

Medusa::~Medusa()
{

}
/***********************************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Implementation file for the Blue Men Class. Implements all functions that runs the program.
************************************************************************************************************/

#include "bluemen.hpp"
#include <iostream>

using std::endl;
using std::cout;

//Constructor for Blue Men's stats.
Bluemen::Bluemen()
{
	numOffDie = 2;
	numDefDie = 3;
	offDie = 10;
	defDie = 6;
	hitpoints = 12;
	defense = 3;
	maxHealth = 12;
	type = "Blue Men";
	than8 = false;
	than4 = false;
}

//Standard attack function.
int Bluemen::attack()
{
	int counter = 0;
	for (int i = 0; i < numOffDie; i++)
	{
		rollResult = rand() % offDie + 1;
		cout << "Blue Men attack and roll a " << rollResult << '.' << endl;
		counter += rollResult;
	}

	return counter;
}

//Standard defend function.
int Bluemen::defend(int attack)
{
	int counter = 0;
	for (int i = 0; i < numDefDie; i++)
	{
		cout << "Blue Men defend and roll a ";
		rollResult = rand() % defDie + 1;
		cout << rollResult << '.' << endl;
		counter += rollResult;
	}
	return counter;
}

//Override function for the Blue Mens' health.
void Bluemen::modifyHealth(int x)
{
	hitpoints -= x;

	//If they haven't fallen below 8 yet, remove one of their defensive die.
	if (hitpoints <= 8 && than8 == false)
	{
		cout << "Blue Men's strength has fallen below 8. They now have only two defensive die!" << endl;
		numDefDie--;
		than8 = true;
	}

	//If they haven't fallen below 4 yet, remove one of their defensive die.
	if (hitpoints <= 4 && than4 == false)
	{
		cout << "Blue Men's strength has fallen below 4. They now have only one defensive die!" << endl;
		numDefDie--;
		than4 = true;
	}
}

//Returns the amount of strength points a character has.
int Bluemen::getHealth()
{
	return hitpoints;
}

//Returns the type of character the player is.
string Bluemen::getType()
{
	return type;
}

//Returns the number of armor points the player has.
int Bluemen::getArmor()
{
	return defense;
}

Bluemen::~Bluemen()
{

}
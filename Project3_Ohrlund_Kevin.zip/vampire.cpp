/***********************************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Implementation file for the Vampire Class. Implements all functions that drive the program.
************************************************************************************************************/

#include "vampire.hpp"
#include <iostream>

using std::cout;
using std::endl;

//Constructor for the vampire's stats.
Vampire::Vampire()
{
	numRolls = 1;
	offDie = 12;
	defDie = 6;
	hitpoints = 18;
	defense = 1;
	maxHealth = 18;
	type = "Vampire"; 
}

//Standard attack function.
int Vampire::attack()
{
	rollResult = rand() % offDie + 1;
	cout << "Vampire attacks and rolls a " << rollResult << '.' << endl;
	return rollResult;
}


//Override function that implements the "Charm" special ability.
int Vampire::defend(int attack)
{
	//Randomly choose if regular defense or special.
	int specialAttack = rand() % 2;

	//Regular defense.
	if (specialAttack == 0)
	{
		cout << "Vampire defends and rolls a ";
		rollResult = rand() % defDie + 1;
		cout << rollResult << '.' << endl;
		return rollResult;
	}

	//Return the attack number, nullifying the attack.
	else
	{
		cout << "Vampire casts charm! Vampire's opponent's attack didn't work!" << endl;
		return attack;
	}
}

//Returns the amount of strength points a Vampire has.
int Vampire::getHealth()
{
	return hitpoints;
}

//Returns the type of Vampire the player is.
string Vampire::getType()
{
	return type;
}

//Returns the number of armor points the player has.
int Vampire::getArmor()
{
	return defense;
}

//Function that modifies the damage based on the result of the round.
void Vampire::modifyHealth(int x)
{
	hitpoints -= x;
}

Vampire::~Vampire()
{

}
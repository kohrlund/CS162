/*********************************************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Implementation file for the Menu Class. Implements all functions that control the flow of the program.
**********************************************************************************************************************/

#include "menu.hpp"
#include "character.hpp"
#include "vampire.hpp"
#include "barbarian.hpp"
#include "bluemen.hpp"
#include "medusa.hpp"
#include "harrypotter.hpp"

#include <iostream>
#include <limits>

using std::cin;
using std::cout;
using std::endl;

Menu::Menu()
{

}

//Display the welcome message and begin the start menu.
void Menu::run()
{
	cout << "Welcome to the Fantasy Combat Game!" << endl;
	cout << "Programmed by Kevin J. Ohrlund." << endl;

	menuChoice = 1;

	//While the user continues to choose to play...
	while (menuChoice == 1)
	{
		cout << "\nEnter your choice below:" << endl;
		cout << "1. Play another simulation." << endl;
		cout << "2. Exit." << endl;

		menuChoice = validate(1, 2);

		//If they choose to continue...
		if (menuChoice == 1)
		{
			//Instantiate the characters for the game.
			Character **characterArray = new Character*[10];
			Character *v1 = new Vampire;
			Character *v2 = new Vampire;
			Character *b1 = new Barbarian;
			Character *b2 = new Barbarian;
			Character *b3 = new Bluemen;
			Character *b4 = new Bluemen;
			Character *m1 = new Medusa;
			Character *m2 = new Medusa;
			Character *h1 = new Harrypotter;
			Character *h2 = new Harrypotter;

			//Set them to the character pointers to the array.
			characterArray[0] = v1;
			characterArray[5] = v2;
			characterArray[1] = b1;
			characterArray[6] = b2;
			characterArray[2] = b3;
			characterArray[7] = b4;
			characterArray[3] = m1;
			characterArray[8] = m2;
			characterArray[4] = h1;
			characterArray[9] = h2;

			//Prompt the user for which characters will fight.
			cout << "\n\nBelow is the list of characters you can choose to fight." << endl;
			cout << "1. Vampire." << endl;
			cout << "2. Barbarian" << endl;
			cout << "3. Blue men." << endl;
			cout << "4. Medusa." << endl;
			cout << "5. Harry Potter." << endl << endl;

			cout << "Enter the the number you would like to play as Player 1." << endl;
			p1Choice = validate(1, 5);

			cout << "\n\nEnter the number you would like to play as Player 2." << endl;
			p2Choice = validate(1, 5);

			//If the user chooses two of the same character, set the second player to the second instantiated character of the same type.
			if (p1Choice == p2Choice)
			{
				isSame = true;
			}

			p1Choice--;
			p2Choice--;

			if (isSame = true)
			{
				p2Choice += 5;
			}

			cout << endl << endl;

			//While both players still have strength remaining...
			while (characterArray[p1Choice]->getHealth() > 0 && characterArray[p2Choice]->getHealth() > 0)
			{
				//Reset the counter.
				int counter = 0;

				//Display the attacker types and strength points.
				cout << characterArray[p1Choice]->getType() << "(P1) attacks " << characterArray[p2Choice]->getType() << "(P2)!" << endl;
				cout << characterArray[p2Choice]->getType() << " has " << characterArray[p2Choice]->getHealth() << " strength point(s)." << endl;

				//Attack and calculate the attack hits.
				counter += characterArray[p1Choice]->attack();

				//Defend and calculate the defense hits.
				counter -= characterArray[p2Choice]->defend(counter);

				//Display the armor points of the defending player.
				cout << characterArray[p2Choice]->getType() << " has " << characterArray[p2Choice]->getArmor() << " armor points." << endl;
				counter -= characterArray[p2Choice]->getArmor();

				//Display the amount of damage inflicted on P1.
				if (counter > 0)
				{
					characterArray[p2Choice]->modifyHealth(counter);
					cout << characterArray[p2Choice]->getType() << " was damaged for " << counter << " points." << endl;
				}

				//Display that the attack was defended.
				else
				{
					cout << characterArray[p2Choice]->getType() << " has blocked the attack!" << endl;
				}

				//Display the player's remaining health.
				cout << "After the attack, "  << characterArray[p2Choice]->getType() << " has " << characterArray[p2Choice]->getHealth() << " health remaining." << endl << endl;

				//If the player is below 1 health, display that they have died.
				if (characterArray[p2Choice]->getHealth() < 1)
				{
					cout << characterArray[p2Choice]->getType() << " has died!" << endl;
				}

				//Else run the next attack.
				else
				{
					//Reset the number of damage inflicted.
					counter = 0;

					//Display the attacker type and strength points remaining.
					cout << characterArray[p2Choice]->getType() << "(P2) attacks " << characterArray[p1Choice]->getType() << "(P1)!" << endl;
					cout << characterArray[p1Choice]->getType() << " has " << characterArray[p1Choice]->getHealth() << " strength point(s)." << endl;

					//Run the attack.
					counter += characterArray[p2Choice]->attack();

					//Run the defense.
					counter -= characterArray[p1Choice]->defend(counter);

					//Display the number of armor points the defending player has.
					cout << characterArray[p1Choice]->getType() << " has " << characterArray[p1Choice]->getArmor() << " armor points." << endl;
					counter -= characterArray[p1Choice]->getArmor();

					//Display the amount of damage inflicted.
					if (counter > 0)
					{
						characterArray[p1Choice]->modifyHealth(counter);
						cout << characterArray[p1Choice]->getType() << " was damaged for " << counter << " points." << endl;
					}

					//Else display that the attack was blocked.
					else
					{
						cout << characterArray[p1Choice]->getType() << " has blocked the attack!" << endl;
					}

					//Display the amount of strength points after the attack.
					cout << "After the attack, " << characterArray[p1Choice]->getType() << " has " << characterArray[p1Choice]->getHealth() << " health remaining." << endl << endl;
				}

				//If the player's strength is below 0, display that the player has died and end the game.
				if (characterArray[p1Choice]->getHealth() < 1)
				{
					cout << characterArray[p1Choice]->getType() << " has died!" << endl;
				}
			}

			//Free the memory.
			delete b1;
			delete b2;
			delete b3;
			delete b4;
			delete v1;
			delete v2;
			delete h1;
			delete h2;
			delete m1;
			delete m2;
			delete[]characterArray;
		}
	}
}

//Helper function to validate user's input.
int Menu::validate(int x, int y)
{
	int z = 0;
	cin >> z;

	while (cin.fail() || z < x || z > y)
	{
		cout << "Invalid entry. Enter a number from " << x << " to " << y << '.' << endl;
		cin.clear();
		cin.ignore(std::numeric_limits<int>::max(), '\n');

		cin >> z;
	}

	return z;
}

//Destructor
Menu::~Menu()
{

}
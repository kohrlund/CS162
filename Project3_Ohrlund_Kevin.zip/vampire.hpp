/*******************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Header file for the Vampire Class.
*******************************************************************************************/
#ifndef VAMPIRE_HPP
#define VAMPIRE_HPP
#include "character.hpp"

class Vampire : public Character
{
public:
	Vampire();
	int attack();
	int defend(int attack);
	void modifyHealth(int x);
	int getHealth();
	string getType();
	int getArmor();
	~Vampire();

private:

};

#endif

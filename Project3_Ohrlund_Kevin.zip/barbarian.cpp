/***********************************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Implementation file for the Barbarian Class. Implements all functions that runs the program.
************************************************************************************************************/

#include "barbarian.hpp"
#include <iostream>

using std::endl;
using std::cout;


//Constructor for the Barbarian.
Barbarian::Barbarian()
{
	numOffDie = 2;
	numDefDie = 2;
	offDie = 6;
	defDie = 6;
	hitpoints = 12;
	defense = 0;
	maxHealth = 12;
	type = "Barbarian";
}

//Standard attack function.
int Barbarian::attack()
{
	int counter = 0;

	for (int i = 0; i < numOffDie; i++)
	{
		rollResult = rand() % offDie + 1;
		cout << "Barbarian attacks and rolls a " << rollResult << '.' << endl;
		counter += rollResult;
	}
	return counter;
}

//Standard defend function.
int Barbarian::defend(int attack)
{
	int counter = 0;
	for (int i = 0; i < numDefDie; i++)
	{
		cout << "Barbarian defends and rolls a ";
		rollResult = rand() % defDie + 1;
		cout << rollResult << '.' << endl;
		counter += rollResult;
	}
	return counter;
}

//Returns the amount of strength points a character has.
int Barbarian::getHealth()
{
	return hitpoints;
}

//Returns the type of character the player is.
string Barbarian::getType()
{
	return type;
}

//Returns the number of armor points the player has.
int Barbarian::getArmor()
{
	return defense;
}

//Function that modifies the damage based on the result of the round.
void Barbarian::modifyHealth(int x)
{
	hitpoints -= x;
}

Barbarian::~Barbarian()
{

}
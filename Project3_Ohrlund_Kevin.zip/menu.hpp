/*******************************************************************************************
**Program Name: Combat Simulator
**Author: Kevin J. Ohrlund
**Date: 13 April 2018
**Description: Header file for the Menu Class.
*******************************************************************************************/
#ifndef MENU_HPP
#define MENU_HPP

class Menu
{
public:
	Menu();
	void run();
	int validate(int x, int y);
	~Menu();

private:
	int menuChoice, p1Choice, p2Choice;
	bool isSame;

};

#endif // !MENU_HPP
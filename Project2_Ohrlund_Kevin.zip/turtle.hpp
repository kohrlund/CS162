/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the turtle class.
****************************************************************************************************************/

#ifndef TURTLE_HPP
#define TURTLE_HPP
#include "animal.hpp"

class Turtle : public Animal
{
public:
	Turtle();
	void setAge(int age);
	int getAge();
	int getFoodCost();
	int getPayoff();
	int getCost();
	void ageDay();
	int getNumBabies();
	~Turtle();

private:

};
#endif
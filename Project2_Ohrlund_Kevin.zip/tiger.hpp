/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the Tiger class.
****************************************************************************************************************/
#ifndef TIGER_HPP
#define TIGER_HPP
#include "animal.hpp"

class Tiger : public Animal
{
public:
	Tiger();
	int getFoodCost();
	int getPayoff();
	int getCost();
	void ageDay();
	int getNumBabies();
	~Tiger();
private:

};

#endif // !TIGER_HPP

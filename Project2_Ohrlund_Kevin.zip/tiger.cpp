/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation file for the tiger class. Inherits from Animal Class.
****************************************************************************************************************/

#include "tiger.hpp"

//Constructor.
Tiger::Tiger()
{
	cost = 10000;
	age = 0;
	baseFoodCost = 50;
	numBabies = 1;
	payoff = 2000;
}

void Tiger::ageDay()
{
	age++;
}

int Tiger::getFoodCost()
{
	return baseFoodCost;
}

int Tiger::getPayoff()
{
	return payoff;
}

int Tiger::getCost()
{
	return cost;
}

int Tiger::getNumBabies()
{
	return numBabies;
}

Tiger::~Tiger()
{

}
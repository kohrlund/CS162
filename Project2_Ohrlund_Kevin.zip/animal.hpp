/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the animal cost. Is the base class for the other animals.
****************************************************************************************************************/

#ifndef ANIMAL_HPP
#define ANIMAL_HPP

class Animal
{
public:
	Animal();
	void setAge(int age);
	int getAge();
	int getFoodCost();
	int getPayoff();
	int getCost();
	void ageDay();
	int getNumBabies();
	~Animal();

private:

protected:
	int age, cost, numBabies, baseFoodCost, payoff;
};

#endif
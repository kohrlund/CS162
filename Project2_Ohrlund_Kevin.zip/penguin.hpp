/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the penugin class.
****************************************************************************************************************/

#ifndef PENGUIN_HPP
#define PENGUIN_HPP
#include "animal.hpp"

class Penguin : public Animal
{
public:
	Penguin();
	~Penguin();
	void setAge(int age);
	int getAge();
	int getFoodCost();
	int getPayoff();
	int getCost();
	void ageDay();
	int getNumBabies();

private:

};

#endif
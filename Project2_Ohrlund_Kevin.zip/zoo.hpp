/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the zoo class. Contains all the data.
****************************************************************************************************************/

#ifndef ZOO_HPP
#define ZOO_HPP

class Zoo
{
public:
	void run();
	int validate(int x, int y);

private:
	int bank, numTigers, numPenguins, numTurtles, gameChoice, dayNumber, profit;

protected:

};

#endif
/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Main file for the program. Instantiates a Zoo object and starts the game.
****************************************************************************************************************/

#include <cstdlib>
#include <ctime>
#include "zoo.hpp"

int main()
{
	//Seed random number generator.
	srand(time(0));

	//Create a zoo object.
	Zoo z1;

	//Run the zoo.
	z1.run();
	return 0;
}
/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation file for the zoo class. Runs the majority of the game.
****************************************************************************************************************/

#include "zoo.hpp"
#include "animal.hpp"
#include "tiger.hpp"
#include "penguin.hpp"
#include "turtle.hpp"

#include <iostream>
#include <limits>
#include <cstdlib>

using std::cin;
using std::cout;
using std::endl;

void Zoo::run()
{
	gameChoice = 1;

	//Greet the user and prompt for their initial choice.
	cout << "Welcome to Zoo Tycoon!" << endl;
	cout << "Programmed by Kevin J. Ohrlund." << endl << endl;

	cout << "Enter your choice below:" << endl;
	cout << "1. Start a new game." << endl;
	cout << "2. Exit." << endl;

	//Validate the user's data.
	gameChoice = validate(1, 2);
	dayNumber = 1;

	//While the user chooses to keep playing the game...
	while (gameChoice != 2)
	{
		//Display the starting instructions.
		int tigerCage = 10, penguinCage = 10, turtleCage = 10;
		bank = 100000;
		cout << "\n\nYou begin the game with $100,000 in the bank.  Good luck, Tycoon!" << endl;

		cout << "\n\nTo start, you must buy 1 or 2 of each type of animal." << endl;
		cout << "How many tigers would you like to buy? They cost $10,000 each." << endl;
		numTigers = validate(1, 2);

		cout << "\n\nHow many Penguins would you like to buy? They cost $1,000 each." << endl;
		numPenguins = validate(1, 2);

		cout << "\n\nHow many turtles would you like to buy? They cost $100 each." << endl;
		numTurtles = validate(1, 2);

		//Create the tiger, penguin, and turtle arrays and subtract the correct amount from the user's bank.
		Tiger *tigers = new Tiger[tigerCage];
		for (int i = 0; i < numTigers; i++)
		{
			tigers[i].setAge(1);
			bank -= tigers[i].getCost();
		}

		Penguin *penguins = new Penguin[penguinCage];
		for (int i = 0; i < numPenguins; i++)
		{
			penguins[i].setAge(1);
			bank -= penguins[i].getCost();
		}

		Turtle *turtles = new Turtle[turtleCage];
		for (int i = 0; i < numTurtles; i++)
		{
			turtles[i].setAge(1);
			bank -= turtles[i].getCost();
		}
		
		//While the user still has money and chooses to continue playing this game...
		while (bank > 0 && gameChoice != 2)
		{
			cout << "Beginning of day " << dayNumber << '!' << endl;
			dayNumber++;
			cout << "Advancing animals' age...";

			//Age all animals by one day.
			for (int i = 0; i < numTigers; i++)
			{
				tigers[i].ageDay();
			}

			for (int i = 0; i < numPenguins; i++)
			{
				penguins[i].ageDay();
			}

			for (int i = 0; i < numTurtles; i++)
			{
				turtles[i].ageDay();
			}

			cout << "All animals have aged 1 day." << endl;

			//Feed the animals by deducting the appropriate cost from their bank.
			cout << "Feeding your animals...";
			for (int i = 0; i < numTigers; i++)
			{
				bank -= tigers[i].getFoodCost();
			}

			for (int i = 0; i < numPenguins; i++)
			{
				bank -= penguins[i].getFoodCost();
			}

			for (int i = 0; i < numTurtles; i++)
			{
				bank -= turtles[i].getFoodCost();
			}

			cout << " All animals fed!" << endl;

			//Display the bank after feeding (for input validation).
			cout << "\nAfter feeding, you have $" << bank << " remaining." << endl;


			//Begin the random event.
			int random = rand() % 4;
			cout << "\nA random event has occurred!" << endl;

			//If 0, an animal has died.
			if (random == 0)
			{
				//hasDied returns whether an animal has died yet or not (in case the user already has 0 of some animal)
				bool hasDied = false;

				while (hasDied == false)
				{
					//Choose an animal type to die.
					int newRand = rand() % 3;

					//Remove one tiger by setting their age back to 0.
					if (newRand == 0 && numTigers > 0)
					{
						cout << "One of your tigers has died." << endl;
						numTigers--;
						tigers[numTigers].setAge(0);
						hasDied = true;
					}

					//Remove one Penguin by setting their age back to 0.
					else if (newRand == 1 && numPenguins > 0)
					{
						cout << "One of your penguins has died." << endl;
						numPenguins--;
						penguins[numPenguins].setAge(0);
						hasDied = true;
					}

					//Remove one Turtle by setting their age back to 0.
					else if (newRand == 2 && numTurtles > 0)
					{
						cout << "One of your turtles has died." << endl;
						numTurtles--;
						turtles[numTurtles].setAge(0);
						hasDied = true;
					}

					//Or display that the user has no animals remaining.
					else if (numTurtles < 1 && numPenguins < 1 && numTigers < 1)
					{
						cout << "You don't have any animals left!" << endl;
						hasDied = true;
					}
				}
			}

			//Boom in attendance gives a bonus for each tiger.
			else if (random == 1)
			{
				int newRand = rand() % 250 + 250;
				cout << "A Boom in attendance has occurred! You receive $" << newRand << " for each of the " << numTigers << " tigers you have!" << endl;

				//Add the money to the bank.
				bank += (numTigers * newRand);
			}

			//Have babies.
			else if (random == 2)
			{
				//Display that none of the user's animals can have babies.
				if (tigers[0].getAge() < 3 && penguins[0].getAge() < 3 && turtles[0].getAge() < 3)
				{
					cout << "None of your animals is old enough to have babies! Nothing happened." << endl;
				}

				else
				{
					//hadBabies returns whether the animal had babies (in case one of the user's animals can't have babies).
					bool hadBabies = false;

					while (hadBabies == false)
					{
						//Generate a random number for the animal to have babies.
						int newRand = rand() % 3;

						//Have a baby tiger.
						if (newRand == 0 && tigers[0].getAge() > 2)
						{
							cout << "\nA baby Tiger is born!" << endl;

							//If the cage is too small, double the size and copy to the tiger array.
							if (numTigers + tigers[0].getNumBabies() > tigerCage)
							{
							tigerCage *= 2;
							Tiger *tempTiger = new Tiger[tigerCage];
							for (int i = 0; i < numTigers; i++)
							{
								tempTiger[i] = tigers[i];
							}
							tigers = tempTiger;
							delete[]tempTiger;
							}

						//Set the age to 1 for all new baby tigers.
						for (int i = numTigers; i < numTigers + tigers[0].getNumBabies(); i++)
						{
							tigers[i].setAge(1);
						}
						numTigers += tigers[0].getNumBabies();
						//Set hadBabies to true to indicate the baby was born.
						hadBabies = true;
					}
					
					//Have a baby penguin.
					else if (newRand == 1 && penguins[0].getAge() > 2)
					{
						cout << "\nA baby penguin is born!" << endl;

						//Resize the cage array if it is too small.
						if (numPenguins + penguins[0].getNumBabies() > penguinCage)
						{
							tigerCage *= 2;
							Penguin *tempPenguin = new Penguin[penguinCage];
							for (int i = 0; i < numPenguins; i++)
							{
								tempPenguin[i] = penguins[i];
							}
							penguins = tempPenguin;
							delete[]tempPenguin;
						}

						//Set all baby ages to 1.
						for (int i = numPenguins; i < numPenguins + penguins[0].getNumBabies(); i++)
						{
							penguins[i].setAge(1);
						}
						numPenguins += penguins[0].getNumBabies();
						//hadBabies = true to indicate the baby was born.
						hadBabies = true;
					}

					else if (newRand == 2 && turtles[0].getAge() > 2)
					{
						cout << "\nA baby turtle is born!" << endl;

						//If the turtle cage is too small, resize.
						if (numTurtles + turtles[0].getNumBabies() > turtleCage)
						{
							turtleCage *= 2;
							Turtle *tempTurtle = new Turtle[turtleCage];
							for (int i = 0; i < numTurtles; i++)
							{
								tempTurtle[i] = turtles[i];
							}
							turtles = tempTurtle;
							delete[]tempTurtle;
						}

						//Set all turtle baby ages to 1.
						for (int i = numTurtles; i < numTurtles + turtles[0].getNumBabies(); i++)
						{
							turtles[i].setAge(1);
						}
						numTurtles += turtles[0].getNumBabies();
						//hadBabies = true to indicate that a baby was born.
						hadBabies = true;
					}
				}
			}
			}

			else
			{
				//Random event 4. Nothing happened.
				cout << "\nNothing happened!" << endl << endl;
			}

			//Calculate all the profits.
			cout << "\n\nGetting animal payoffs for the day!" << endl;
			profit = 0;
			for (int i = 0; i < numTigers; i++)
			{
				bank += tigers[0].getPayoff();
				profit += tigers[0].getPayoff();
			}

			for (int i = 0; i < numPenguins; i++)
			{
				bank += penguins[0].getPayoff();
				profit += penguins[0].getPayoff();
			}

			for (int i = 0; i < numTurtles; i++)
			{
				bank += turtles[0].getPayoff();
				profit += turtles[0].getPayoff();
			}

			//Display the profits for the day.
			cout << "Today, you made $" << profit << " in profit. You now have $" << bank << " remaining." << endl;

			//Prompt the user if they would like to buy a new adult animal.
			cout << "\nWould you like to buy some adult animals? Enter your choice below:" << endl;
			cout << "1. Buy a tiger for $10,000." << endl;
			cout << "2. Buy a Penguin for $1,000." << endl;
			cout << "3. Buy a Turtle for $100." << endl;
			cout << "4. Don't buy a new animal." << endl;

			gameChoice = validate(1, 4);

			//Use the same concept as having a baby above to resize cages as necessary.
			if (gameChoice == 1)
			{
				bank -= tigers[0].getCost();
				if (numTigers + 1 > tigerCage)
				{
					tigerCage *= 2;
					Tiger *tempTiger = new Tiger[tigerCage];
					for (int i = 0; i < numTigers; i++)
					{
						tempTiger[i] = tigers[i];
					}
					tigers = tempTiger;
					delete[]tempTiger;
				}

				tigers[numTigers].setAge(3);
				numTigers++;
			}

			else if (gameChoice == 2)
			{
				bank -= penguins[0].getCost();
				if (numPenguins + 1 > penguinCage)
				{
					penguinCage *= 2;
					Penguin *tempPenguin = new Penguin[penguinCage];
					for (int i = 0; i < numPenguins; i++)
					{
						tempPenguin[i] = penguins[i];
					}
					penguins = tempPenguin;
					delete[]tempPenguin;
				}
				penguins[numPenguins].setAge(3);
				numPenguins++;
			}

			else if (gameChoice == 3)
			{
				bank -= turtles[0].getCost();
				if (numTurtles + 1 > turtleCage)
				{
					turtleCage *= 2;
					Turtle *tempTurtle = new Turtle[turtleCage];
					for (int i = 0; i < numTurtles; i++)
					{
						tempTurtle[i] = turtles[i];
					}
					turtles = tempTurtle;
					delete[]tempTurtle;
				}
				turtles[numTurtles].setAge(3);
				numTurtles++;
			}

			//While the user still has money...
			if (bank > 0)
			{
				//Display the current situation.
				cout << "\n\nEnd of the day.  Here is your current status:" << endl;
				cout << "You have $" << bank << " remaining." << endl;
				cout << "You have " << numTigers << " Tigers aged ";
				for (int i = 0; i < numTigers; i++)
				{
					cout << tigers[i].getAge() << ", ";
				}

				cout << "\nYou have " << numPenguins << " Penguins aged ";
				for (int i = 0; i < numPenguins; i++)
				{
					cout << penguins[i].getAge() << ", ";
				}

				cout << "\nYou have " << numTurtles << " Turtles aged ";
				for (int i = 0; i < numTurtles; i++)
				{
					cout << turtles[i].getAge() << ", ";
				}

				//Prompt the user for their choice to continue or exit to the main menu.
				cout << "\n\nEnter your choice below:" << endl;
				cout << "1. Play another day." << endl;
				cout << "2. Exit to the main menu." << endl;
				gameChoice = validate(1, 2);
			}

			//Display that the user is out of money.
			else
			{
				cout << "You have run out of money!" << endl;
			}
		}
		//Free the memory.
		delete[]tigers;
		delete[]penguins;
		delete[]turtles;

		//Prompt the user if they would like to start a new game or exit.
		cout << "\n\nGame over.  Would you like to play again? Enter your choice below." << endl;
		cout << "1. Start a new game." << endl;
		cout << "2. Exit." << endl;
		gameChoice = validate(1, 2);
	}

}

//Function receives the user's input and validates based off the min and max sent to the function.
int Zoo::validate(int x, int y)
{
	int z = 0;
	cin >> z;

	while (cin.fail() || z < x || z > y)
	{
		cout << "Invalid entry. Enter a number from " << x << " to " << y << '.' << endl;
		cin.clear();
		cin.ignore(std::numeric_limits<int>::max(), '\n');

		cin >> z;
	}

	return z;
}
#include "animal.hpp"

//Constructor.
Animal::Animal()
{
	cost = 0;
	age = 0;
	baseFoodCost = 10;
	payoff = 0;
	numBabies = 0;
}

//Sets the animal's age.
void Animal::setAge(int age)
{
	this->age = age;
}

//Returns the animal's age.
int Animal::getAge()
{
	return age;
}

//Returns the animal's food cost.
int Animal::getFoodCost()
{
	return baseFoodCost;
}

//Returns the animal's payoff.
int Animal::getPayoff()
{
	return payoff;
}

//Returns the animal's cost.
int Animal::getCost()
{
	return cost;
}

//Ages an animal by 1 day.
void Animal::ageDay()
{
	age++;
}

//Returns the number of babies an animal has.
int Animal::getNumBabies()
{
	return numBabies;
}

//Destructor.
Animal::~Animal()
{

}
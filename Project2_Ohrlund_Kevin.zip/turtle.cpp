/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation file for the Turtle class. Inherits from the Animal class.
****************************************************************************************************************/
#include "turtle.hpp"

//Constructor.
Turtle::Turtle()
{
	cost = 100;
	age = 0;
	baseFoodCost = 5;
	payoff = 5;
	numBabies = 10;
}
void Turtle::setAge(int age)
{
	this->age = age;
}

int Turtle::getAge()
{
	return age;
}

int Turtle::getFoodCost()
{
	return baseFoodCost;
}

int Turtle::getPayoff()
{
	return payoff;
}

int Turtle::getCost()
{
	return cost;
}

void Turtle::ageDay()
{
	age++;
}

int Turtle::getNumBabies()
{
	return numBabies;
}

Turtle::~Turtle()
{

}
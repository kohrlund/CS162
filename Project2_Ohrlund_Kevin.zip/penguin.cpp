/***************************************************************************************************************
**Program Name: Zoo tycoon
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation for the Penguin class. Inherits from Animal.
****************************************************************************************************************/
#include "penguin.hpp"

//Constructor.
Penguin::Penguin()
{
	cost = 1000;
	age = 0;
	baseFoodCost = 10;
	numBabies = 5;
	payoff = 100;
}

void Penguin::setAge(int age)
{
	this->age = age;
}

int Penguin::getAge()
{
	return age;
}

int Penguin::getFoodCost()
{
	return baseFoodCost;
}

int Penguin::getPayoff()
{
	return payoff;
}

int Penguin::getCost()
{
	return cost;
}

void Penguin::ageDay()
{
	age++;
}

int Penguin::getNumBabies()
{
	return numBabies;
}

Penguin::~Penguin()
{

}
/*******************************************************************************
** Program name: Matrix Determinant
** Author: Kevin J. Ohrlund
** Date: 8 April 2018
** Description: Header file for the readMatrix function.
*******************************************************************************/

#ifndef READMATRIX_HPP
#define READMATRIX_HPP

void readMatrix(int **matrix, int matrixSize);

#endif

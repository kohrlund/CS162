/*******************************************************************************
** Program name: Matrix Determinant - matrixMain
** Author: Kevin J. Ohrlund
** Date: 8 April 2018
** Description: This program calculates the determinant of a 2x2 or 3x3 matrix.
*******************************************************************************/

#include <iostream>
#include "determinant.hpp"
#include "readMatrix.hpp"

using std::cin;
using std::cout;
using std::endl;

void readMatrix(int **matrix, int matrixSize1);
int determinant(int **matrix, int matrixSize1);
int** makeMatrix(int matrixSize1, int matrixSize2);
void deleteMatrix(int **matrix, int matrixSize1);

int main()
{
     int matrixSize1 = 0;

     cout << "Enter the size of the matrix to be evaluated. Enter 2 or 3 for a 2x2 or 3x3 matrix." << endl;
     cin >> matrixSize1;

     while (!(matrixSize1 == 2 || matrixSize1 == 3))
     {
          cout << "Invalid entry. Enter 2 or 3 for a 2x2 or 3x3 matrix." << endl;
          cin >> matrixSize1;
     }

     int **matrix = makeMatrix(matrixSize1, matrixSize1);

     readMatrix(matrix, matrixSize1);

     cout << endl;

     cout << determinant(matrix, matrixSize1) << endl;

     deleteMatrix(matrix, matrixSize1);

     return 0;
}

//Allocates the memory and initializes the matrix.
int** makeMatrix(int matrixSize1, int matrixSize2)
{
     int** matrix = new int*[matrixSize1];

     for (int i = 0; i < matrixSize1; i++)
     {
          matrix[i] = new int[matrixSize2];
     }

     return matrix;
}

//Frees the memory of the matrix.
void deleteMatrix(int **matrix, int matrixSize1)
{
     cout << endl;

     for (int i = 0; i < matrixSize1; i++)
     {
          delete[] matrix[i];
     }
     delete[] matrix;

     //cout << "Memory freed!" << endl;
}

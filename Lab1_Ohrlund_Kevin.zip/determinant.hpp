/*******************************************************************************
** Program name: Matrix Determinant - determinant.hpp
** Author: Kevin J. Ohrlund
** Date: 8 April 2018
** Description: Header file for determinant.cpp
*******************************************************************************/

#ifndef DETERMINANT_HPP
#define DETERMINANAT_HPP

int determinant(int **matrix, int matrixSize1);

#endif

/***********************************************************************************************************
** Program name: Matrix Determinant - determinant();
** Author: Kevin J. Ohrlund
** Date: 8 April 2018
** Description: Displays the matrix, calculates the determinant, and prints the determinant of that matrix.
************************************************************************************************************/

#include "determinant.hpp"
#include <iostream>

using std::cin;
using std::cout;
using std::endl;

int determinant(int **matrix, int matrixSize1)
{

     cout << "Your matrix:" << endl << endl;

     for (int i = 0; i < matrixSize1; i++)
     {
          cout << '|';
          for (int j = 0; j < matrixSize1; j++)
          {
                    cout << matrix[i][j] << '|';
          }
          cout << endl;
     }

     cout << endl;

     int determinant = 0;

     cout << "Your determinant is:" << endl;

     if (matrixSize1 == 2)
     {
          determinant = (matrix[0][0] * (matrix[1][1]) - (matrix[1][0] * matrix[0][1]));
     }

     if (matrixSize1 == 3)
     {
    determinant =
        (matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])) -
        (matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])) +
        (matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0]));

     return determinant;
    }
}

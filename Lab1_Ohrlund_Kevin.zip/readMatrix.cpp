/*******************************************************************************
** Program name: Matrix Determinant - readMatrix();
** Author: Kevin J. Ohrlund
** Date: 8 April 2018
** Description: Implementation for the readMatrix function. Takes input from the
     user and creates the matrix with those integers.
*******************************************************************************/

#include "readMatrix.hpp"
#include <iostream>

using std::cin;
using std::cout;
using std::endl;

void readMatrix(int **matrix, int matrixSize1)
{
     int matrixInput = 0;

     if (matrixSize1 == 2)
     {
          cout << "Enter the 4 numbers in your matrix." << endl;
          for (int i = 0; i < matrixSize1; i++)
          {
               for (int j = 0; j < matrixSize1; j++)
               {
                    cin >> matrixInput;
                    matrix[i][j] = matrixInput;
               }
          }
     }

     if (matrixSize1 == 3)
     {
          cout << "Enter the 9 numbers in your matrix." << endl;
          for (int i = 0; i < matrixSize1; i++)
          {
               for (int j = 0; j < matrixSize1; j++)
               {
                    cin >> matrixInput;
                    matrix[i][j] = matrixInput;
               }
          }
     }
     cout << endl;
}

/******************************************************************************************************************************************
**Author: Kevin J. Ohrlund
**Date: 8 October 2017
**Description: This program reads a text file, counts the number of each letter in each paragraph, and writes it to a user-specified file.
*******************************************************************************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include "letterFunctions.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::iostream;
using std::ifstream;
using std::ofstream;
using std::ios;

void count_letters(ifstream &ifs, int* freqArray);

int main()
{
     //Declare the string for the input file and create the input stream.
     ifstream ifs;
     string inputFileName;

     //Initialize the array for the frequency of each letter.
     int *freqArray = new int[26];

     //Prompt the user for the input file name.
     cout << "Enter the name of the file to be analyzed." << endl;
     cin >> inputFileName;

     //Open the file.
     ifs.open(inputFileName.c_str());

     //If the file doesn't exist, prompt the user for a new file.
     while (ifs.fail())
     {
          cout << "Invalid entry. Enter the name of the file to be analyzed." << endl;
          cin >> inputFileName;
          
          ifs.open(inputFileName.c_str());
     }
     
     //Run the functions.
     count_letters(ifs, freqArray);

     //Close the input file.
     ifs.close();

     //Free the memory.
     delete[] freqArray;

     return 0;
}
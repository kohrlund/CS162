/******************************************************************************************************************************************
**Author: Kevin J. Ohrlund
**Date: 8 October 2017
**Description: Header file for letterFunctions.cpp.
*******************************************************************************************************************************************/

#ifndef LETTERFUNCTIONS_HPP
#define LETTERFUNCTIONS_HPP
#include <iostream>
#include <fstream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;

void count_letters(ifstream &, int*);
void output_letters(ofstream &, int*);

#endif
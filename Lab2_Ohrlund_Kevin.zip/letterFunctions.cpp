/******************************************************************************************************************************************
**Author: Kevin J. Ohrlund
**Date: 8 October 2017
**Description: This file contains the functions that run the program. One to read and analyze the letters and one to write to the new file.
*******************************************************************************************************************************************/
#include <fstream>
#include <iostream>
#include <string>
#include "letterFunctions.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::string;

ofstream ofs;

void count_letters(ifstream &ifs, int* freqArray)
{
     //Initialize new variables.
     int arrayModifier = 0;
     char input = ' ';
     //Loop untilthe end of file.
     while (input != EOF)
     {
          //Reset the array to 0's.
          for (int i = 0; i < 26; i++)
          {
               freqArray[i] = 0;
          }

          //Read the first character of the file.
          input = ifs.get();

          while (!(input == '\n' || input == EOF))
          {
               //Convert char to upper case if needed.
               if ((int)input >= 97 && (int)input <= 122)
               {
                    input = toupper(input);
               }

               //Set the array counter.
               if ((int)input >= 65 && (int)input <= 90)
               {
                    //Set the array modifier to the corresponding letter, and add one to the counter.
                    arrayModifier = ((int)input - 65);
                    freqArray[arrayModifier]++;
               }
               //Get the next character.
               input = ifs.get();
          }
          //Write the letters to the file.
          output_letters(ofs, freqArray);
     }
}

void output_letters(ofstream &ofs, int* freqArray)
{
     string outputFileName;

     //Prompt the user for the output file name.
     cout << "Enter the name of the file you would like to output this paragraph's analysis to." << endl;
     cin >> outputFileName;

     //Open the file.
     ofs.open(outputFileName.c_str());

     //Start the loop to write the file.

     int l = 65;//For the ASCII letter.
     for (int i = 0; i < 26; i++)
     {
          ofs << (char)l << ":" << freqArray[i] << endl;
          l++;
     }

     //Close the file.
     ofs.close();
}
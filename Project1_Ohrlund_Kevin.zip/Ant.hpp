/***************************************************************************************************************
**Program Name: Langton's Ant Simulator
**Author: Kevin J. Ohrlund
**Date: 12 April 2018
**Description: Header file for the ant class.
****************************************************************************************************************/
#ifndef ANT_HPP
#define ANT_HPP

class Ant
{
public:
     void makeBoard(char **boardMatrix, int numRows, int numCols, int startRow, int startCol);
     void printBoard(char **boardMatrix, int numRows, int numCols);
     void runSim(char **boardMatrix, int startRowMod, int startColMod, int numTurns, int numRowsMod, int numColsMod);

private:
     int direction;
     int xCoord;
     int yCoord;
     bool placeHolder;

};

#endif

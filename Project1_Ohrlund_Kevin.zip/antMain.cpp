/***************************************************************************************************************
**Program Name: Langton's Ant Simulator
**Author: Kevin J. Ohrlund
**Date: 12 April 2018
**Description: Main file for the program. Includes the start menu and initializes the board matrix.
****************************************************************************************************************/
#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include <string>
#include <limits>
#include "Ant.hpp"

using std::cin;
using std::cout;
using std::endl;

int startMenu(int *menuArray);

int main()
{
     //Display welcome message.
     cout << "Welcome to Langton's Ant Simulator!" << endl;
     cout << "Author: Kevin J. Ohrlund" << endl << endl;
     cout << "**Note: Random start location is activated for extra credit." << endl;
     cout << "**Note: In this simulation, the ant will be represented by the '@' character for readability." << endl;

     //Initialize all necessary variables.
     int numCols = 0, numRows = 0, numTurns = 0, randChoice = 0, startRow = 0, startCol = 0, gameState = 1, numRowsMod = 0, numColsMod = 0, startRowMod = 0, startColMod = 0;
     srand(time(0));

     //Loop to determine whether the simulation will be run again.
     while (gameState == 1)
     {
          //Initialize the menu options
          int *menuArray = new int[6];

          //Run the start menu and convert the data.
          startMenu(menuArray);
          numRows = menuArray[0];
          numCols = menuArray[1];
          numTurns = menuArray[2];
          startRow = menuArray[4];
          startCol = menuArray[5];

          delete[] menuArray;

          //Modify the starting parameters to create space for the edges of the board.
          numRowsMod = numRows + 2;
          numColsMod = numCols + 2;
          startRowMod = startRow + 1;
          startColMod = startCol + 1;


          //Initialize the matrix and Ant object.
          char **boardMatrix = new char*[numRowsMod];
          for (int i = 0; i < numRowsMod; i++)
          {
               boardMatrix[i] = new char[numColsMod];
          }

          Ant ant1;

          //Run the simulation.
          ant1.makeBoard(boardMatrix, numRowsMod, numColsMod, startRowMod, startColMod);
          ant1.printBoard(boardMatrix, numRowsMod, numColsMod);
          ant1.runSim(boardMatrix, startRowMod, startColMod, numTurns, numRowsMod, numColsMod);

          //Free the memory.
          for (int i = 0; i < numRowsMod; i++)
          {
               delete[] boardMatrix[i];
          }
          delete[] boardMatrix;


          cout << "Simulation complete!" << endl << endl;
          cout << "Would you like to run a new simulation?" << endl;
          cout << "Enter your choice below:" << endl;
          cout << "1. Run a new simulation." << endl;
          cout << "2. Quit." << endl;
          cin >> gameState;

          while (cin.fail() || (!(gameState == 1 || gameState == 2)))
          {
               cout << "Invalid entry. Enter 1 to run a new simulation or 2 to quit." << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<char>::max(), '\n');
               cin >> gameState;
          }
     }
     return 0;
}

//Start menu gathers the user's input and returns the array to the main function.
int startMenu(int *menuArray)
{
     cout << "\n How many rows will this simulation board contain?" << endl;
     cin >> menuArray[0];
     while (cin.fail() || menuArray[0] < 2)
     {
          cout << "Invalid entry. Enter a number greater than 1." << endl;
          cin.clear();
          cin.ignore(std::numeric_limits<char>::max(), '\n');
          cin >> menuArray[0];
     }

     cout << "\nHow many columns will this simulation board contain?" << endl;
     cin >> menuArray[1];
     while (cin.fail() || menuArray[1] < 2)
     {
          cout << "Invalid entry. Enter a number greater than 1." << endl;
          cin.clear();
          cin.ignore(std::numeric_limits<char>::max(), '\n');
          cin >> menuArray[1];
     }

     cout << "How many turns will this simulation run?" << endl;
     cin >> menuArray[2];
     while (cin.fail() || menuArray[2] < 0)
     {
          cout << "Invalid entry. Enter a number greater than -1." << endl;
          cin.clear();
          cin.ignore(std::numeric_limits<char>::max(), '\n');
          cin >> menuArray[2];
     }

     cout << "\nEnter your choice below:" << endl;
     cout << "1. Manual start position." << endl;
     cout << "2. Random start position." << endl;
     cin >> menuArray[3];

     while (cin.fail() || !(menuArray[3] == 1 || menuArray[3] == 2))
     {
          cout << "Invalid entry. Enter 1 for manual or 2 for random start position." << endl;
          cin.clear();
          cin.ignore(std::numeric_limits<char>::max(), '\n');
          cin >> menuArray[3];
     }

     if (menuArray[3] == 1)
     {
          cout << "Which row will the ant start in?" << endl;
          cin >> menuArray[4];

          while (cin.fail() || menuArray[4] < 0 || menuArray[4] > menuArray[0] - 1)
          {
               cout << "Invalid entry. Enter a number 0-" << (menuArray[0] - 1) << "." << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<char>::max(), '\n');
               cin >> menuArray[4];
          }

          cout << "Which column will the ant start in?" << endl;
          cin >> menuArray[5];

          while (cin.fail() || menuArray[5] < 0 || menuArray[5] > menuArray[1] - 1)
          {
               cout << "Invalid entry. Enter a number 0-" << (menuArray[1] - 1) << "." << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<char>::max(), '\n');
               cin >> menuArray[5];
          }

     }

     if (menuArray[3] == 2)
     {
          cout << "Setting random ant location..." << endl;
          menuArray[4] = rand() % menuArray[0];
          menuArray[5] = rand() % menuArray[1];

          cout << "Random location set. Starting at:" << endl;
          cout << "Row: " << menuArray[4] << endl << "Column: " << menuArray[5] << endl;
     }
     return *menuArray;
}

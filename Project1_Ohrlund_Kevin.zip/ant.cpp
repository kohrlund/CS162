/***************************************************************************************************************
**Program Name: Langton's Ant Simulator
**Author: Kevin J. Ohrlund
**Date: 12 April 2017
**Description: Implementation for the ant class. Sets up the board and runs the simulation.
****************************************************************************************************************/

#include "Ant.hpp"
#include <iostream>
#include <cstdlib>
#include <ctime>

using std::cin;
using std::cout;
using std::endl;

int direction = 0, xCoord = 0, yCoord = 0;

//Initializes the board.
void Ant::makeBoard(char **boardMatrix, int numRowsMod, int numColsMod, int startRowMod, int startColMod)
{
     for (int i = 0; i < numRowsMod; i++)
     {
          for (int j = 0; j < numColsMod; j++)
          {
               //Sets the outside edges to an 'X' character and the rest of the board a space character.
               if (j == 0 || j == (numColsMod - 1) || i == 0 || i == (numRowsMod - 1))
               {
                    boardMatrix[i][j] = 'X';
               }

               else
               {
                    boardMatrix[i][j] = ' ';
               }
          }
     }
     boardMatrix[startRowMod][startColMod] = '@';
}

//Prints the starting board (mainly used during my early testing and input validation).
void Ant::printBoard(char **boardMatrix,  int numRowsMod, int numColsMod)
{
     for (int i = 0; i < numRowsMod; i++)
     {
          for (int j = 0; j < numColsMod; j++)
          {
               cout << boardMatrix[i][j];
          }
          cout << endl;
     }
}

//Moves the ant the desired number of times and manipulates the squares the board.
void Ant::runSim(char **boardMatrix, int startRowMod, int startColMod, int numTurns, int numRowsMod, int numColsMod)
{
     xCoord = startRowMod;
     yCoord = startColMod;
     direction = rand();
     bool placeHolder = false;

     for (int i = 0; i < numTurns; i++)
     {
          //Determine whether the square previously held a black or white space and change it.
          if (placeHolder == false)
          {
               boardMatrix[xCoord][yCoord] = '#';
          }

          if (placeHolder == true)
          {
               boardMatrix[xCoord][yCoord] = ' ';
          }

          //Move ant to the new square based on the direction.
          //If the ant goes beyond the edges of the board, move to the opposite side.
          if (direction % 4 == 0)
          {
               xCoord--;
               if (xCoord < 1)
               {
                    xCoord = numRowsMod - 2;
               }
          }

          if (direction % 4 == 1)
          {
               yCoord++;
               if (yCoord > numColsMod - 2)
               {
                    yCoord = 1;
               }
          }

          if (direction % 4 == 2)
          {
               xCoord++;
               if (xCoord > numRowsMod - 2)
               {
                    xCoord = 1;
               }
          }

          if (direction % 4 == 3)
          {
               yCoord--;
               if (yCoord < 1)
               {
                    yCoord = numColsMod - 2;
               }
          }

          //Determine whether the new square is black or white, and update the placeholder.
          if (boardMatrix[xCoord][yCoord] == ' ')
          {
               placeHolder = false;
               direction++;
          }

          if (boardMatrix[xCoord][yCoord] == '#')
          {
               placeHolder = true;
               direction--;
          }

          //Set the ant at the new position.
          boardMatrix[xCoord][yCoord] = '@';


          //Print the board.
          for (int j = 0; j < numRowsMod; j++)
          {
               for (int k = 0; k < numColsMod; k++)
               {
                    cout << boardMatrix[j][k];
               }
               cout << endl;
          }
     }
}

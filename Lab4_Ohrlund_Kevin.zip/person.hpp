/***************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the person class.
****************************************************************************************************************/

#ifndef PERSON_HPP
#define PERSON_HPP

#include <iostream>
#include <string>

using std::string;

class Person
{
public:
     void virtual do_work();
     void virtual printInfo();
     void virtual setParameters(string name, int age, double x);
     string getName();
     Person();
     ~Person();

private:

protected:
     string name;
     int age;
};

#endif

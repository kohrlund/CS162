/*************************************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation file for the instructor class. Sets the parameters for an instructor and handles instructor class data.
**************************************************************************************************************************************/

#include "instructor.hpp"
#include "person.hpp"
#include <iostream>
#include <cstdlib>
#include <string>

using std::string;
using std::cout;
using std::endl;

//Constructor.
Instructor::Instructor()
{
     name = "No name";
     age = 0;
     rating = 0;
}

//Function to set instructors' parameters.
void Instructor::setParameters(string name, int age, double rating)
{
     this->name = name;
     this->age = age;
     this->rating = rating;
}

//Function for the instructor to grade papers.
void Instructor::do_work()
{
     cout << name << " graded papers for " << (rand() % 12 + 1) << " hours.\n\n" << endl;
}

//Function to print the instructor's information.
void Instructor::printInfo()
{
     cout << "Name: " << name << endl;
     cout << "Age: " << age << endl;
     cout << "Rating: " << rating << endl;
}

//Destructor.
Instructor::~Instructor()
{
}

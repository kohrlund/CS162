/***************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the building class.
****************************************************************************************************************/

#ifndef BUILDING_HPP
#define BUILDING_HPP
#include <iostream>
#include <string>

using std::string;

class Building
{
public:
     Building();
     Building(string name, int size, string address);
     ~Building();
     void printInfo();

private:
     string name;
     int size;
     string address;

protected:

};

#endif

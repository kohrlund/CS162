/***************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation file for the university class. Handles users' input and runs the program.
****************************************************************************************************************/

#include <iostream>
#include <limits>
#include "university.hpp"

using std::cin;
using std::cout;
using std::endl;

//Begin the program.
void University::run()
{
     //Greet the user.
     cout << "Welcome to Oregon State University's Information System!" << endl;
     cout << "Programmed by Kevin J. Ohrlund" << endl << endl;

     menuOption = 0;
     name = "Oregon State University";

     //While the user chooses to continue, display the menu.
     while (menuOption != 4)
     {
          cout << "\nEnter your choice below:" << endl;
          cout << "1. Print information about all the buildings." << endl;
          cout << "2. Print information of everybody at the university." << endl;
          cout << "3. Choose a person to do work." << endl;
          cout << "4. Exit." << endl;

          cin >> menuOption;

          while (cin.fail() || menuOption < 1 || menuOption > 4)
          {
               cout << "\nInvalid entry. Please enter your choice from the following menu:" << endl;
               cout << "1. Print information about all the buildings." << endl;
               cout << "2. Print information of everybody at the university." << endl;
               cout << "3. Choose a person to do work." << endl;
               cout << "4. Exit." << endl;

               cin.clear();
               cin.ignore(std::numeric_limits<int>::max(), '\n');

               cin >> menuOption;
          }

          //Instantiate the building array and buildings.
          Building *buildings = new Building[5];

          Building b1("Adams Hall", 11168, "606 SW 15th St.");
          Building b2("Aero Engineering Lab", 3637, "852 SW 30th St.");
          Building b3("Agricultural & Life Sciences Building", 185629, "2750 SW Campus Way");
          Building b4("Anderson and Keeling Memorial Target Range", 4550, "460 SW 15th St.");
          Building b5("Apiary (Bee) Building", 2996, "844 SW 35th St.");

          buildings[0] = b1;
          buildings[1] = b2;
          buildings[2] = b3;
          buildings[3] = b4;
          buildings[4] = b5;

          //Instantiate the person array with students and instructors.
          Person *s1 = new Student;
          Person *s2 = new Student;
          Person *s3 = new Student;
          Person *i1 = new Instructor;
          Person *i2 = new Instructor;

          Person **people = new Person* [5];

          people[0] = s1;
          people[1] = s2;
          people[2] = s3;
          people[3] = i1;
          people[4] = i2;

          s1->setParameters("Amy Adams", 18, 3.48);
          s2->setParameters("Brian Barnes", 19, 3.74);
          s3->setParameters("Cynthia Chadwick", 20, 4.0);
          i1->setParameters("Delilah Dursley", 45, 4.6);
          i2->setParameters("Eggbert Everson", 60, 3.43);

          //Display the user's choice.
          if (menuOption == 1)
          {
               //Print information about all the buildings.
               printBuildings(buildings);
          }

          else if (menuOption == 2)
          {
               //Print information about all the people.
               cout << endl;
               printPeople(people);
          }
          else if (menuOption == 3)
          {
               //Choose a person to do work.
               chooseWork(people);
          }

          //Free the memory.
          delete s1;
          delete s2;
          delete s3;
          delete i1;
          delete i2;
          delete[]buildings;
          delete[]people;
     }
}

//Function to print all the buildings.
void University::printBuildings(Building *buildings)
{
     for (int i = 0; i < 5; i++)
     {
          buildings[i].printInfo();
     }
}

//Function to print all the people.
void University::printPeople(Person **people)
{
     for (int i = 0; i < 5; i++)
     {
          people[i]->printInfo();
          cout << endl;
     }
}

//Allows the user to select a person to do work, then display the appropriate "do_work" call based on the type of person.
void University::chooseWork(Person **people)
{
     int selector = 0;
     cout << "\nSelect a person to work from the list below." << endl;
     for (int i = 0; i < 5; i++)
     {
          cout << i + 1 << ". " << people[i]->getName() << endl;
     }

     cin >> selector;
     while (cin.fail() || selector < 1 || selector > 5)
     {
          cout << "\nInvalid entry. Choose the person below to work." << endl;
          cin.clear();
          cin.ignore(std::numeric_limits<int>::max(), '\n');

          for (int i = 0; i < 5; i++)
          {
               cout << i + 1 << ". " << people[i]->getName() << endl;
          }
          cin >> selector;
     }

     selector--;
     people[selector]->do_work();
}

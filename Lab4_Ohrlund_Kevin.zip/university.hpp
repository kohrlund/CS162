/***************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the university class.
****************************************************************************************************************/

#ifndef UNIVERSITY_HPP
#define UNIVERSITY_HPP
#include <iostream>
#include "building.hpp"
#include "person.hpp"
#include "student.hpp"
#include "instructor.hpp"

using std::string;

class University
{
public:
     void run();
     void printBuildings(Building *buildings);
     void printPeople(Person **people);
     void chooseWork(Person **people);

private:
     int menuOption;

protected:
     int numBuildings;
     int numPeople;
     string name;
};

#endif

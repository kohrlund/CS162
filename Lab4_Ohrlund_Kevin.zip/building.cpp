/***************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation file for the building class. Handles all data related to the buildings.
****************************************************************************************************************/

#include "building.hpp"
#include <iostream>

using std::cout;
using std::endl;

//Default constructor
Building::Building()
{
     name = "No name";
     size = 0;
     address = "No address";
}


//Constructor with parameters
Building::Building(string name, int size, string address)
{
     this->name = name;
     this->size = size;
     this->address = address;
}

//Prints information about a building.
void Building::printInfo()
{
     cout << "\nName: " << name << endl;
     cout << "Size: " << size << endl;
     cout << "Address: " << address << endl;
}

//Destructor.
Building::~Building()
{

}
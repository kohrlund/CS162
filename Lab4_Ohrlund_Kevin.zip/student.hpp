/***************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the student class.
****************************************************************************************************************/

#ifndef STUDENT_HPP
#define STUDENT_HPP
#include "person.hpp"
#include <string>
#include <iostream>

using std::string;

class Student : public Person
{
public:
     Student();
     void setParameters(string name, int age, double gpa);
     void printInfo();
     void do_work();
     ~Student();

private:
     double gpa;

protected:

};
#endif

/***************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Main function. Seeds the random number generator and begins the program.
****************************************************************************************************************/

#include <ctime>
#include <cstdlib>
#include "university.hpp"

using std::cin;
using std::cout;
using std::endl;

int main()
{
     University u1;
     srand(time(0));
     u1.run();
     return 0;
}

/************************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation file for the person class. Sets the parameters for a person and handles person class data.
*************************************************************************************************************************/

#include "person.hpp"
#include <iostream>
#include <cstdlib>

using std::cout;
using std::endl;

//Default constructor.
Person::Person()
{
     name = "No Name";
     age = 0;
}

//Function to set the parameters of the person.
void Person::setParameters(string name, int age, double x)
{
     this->name = name;
     this->age = age;
}

//Function for the person to work.
void Person::do_work()
{
     cout << name << " worked for " << (rand() % 12) + 1 << " hours" << endl;
}

//Function to print the person's information.
void Person::printInfo()
{
     cout << "Name: " << name << endl;
     cout << "Age: " << age << endl << endl;
}

//Function to return the person's name.
string Person::getName()
{
     return name;
}


//Destructor
Person::~Person()
{

}

/***************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Header file for the instructor class.
****************************************************************************************************************/

#ifndef INSTRUCTOR_HPP
#define INSTRUCTOR_HPP

#include "university.hpp"
#include "person.hpp"
#include "building.hpp"
#include "student.hpp"
#include "instructor.hpp"

class Instructor : public Person
{
public:
     void do_work();
     void printInfo();
     Instructor();
     void setParameters(string name, int age, double rating);
     ~Instructor();

private:
     double rating;

protected:

};

#endif

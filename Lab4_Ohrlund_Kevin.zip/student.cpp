/**************************************************************************************************************************
**Program Name: OSU Information System
**Author: Kevin J. Ohrlund
**Date: 29 April 2018
**Description: Implementation file for the student class. Sets the parameters for a student and handles student class data.
***************************************************************************************************************************/

#include "person.hpp"
#include "student.hpp"
#include "university.hpp"
#include <cstdlib>

using std::cout;
using std::endl;

//Default constructor.
Student::Student()
{
     name = "No name";
     age = 0;
     gpa = 0;
}

//Function to set the student parameters.
void Student::setParameters(string name, int age, double gpa)
{
     this->name = name;
     this->age = age;
     this->gpa = gpa;
}

//Function for the student to do homework.
void Student::do_work()
{
     cout << name << " did " << (rand() % 12 + 1) << " hours of homework.\n\n" << endl;
}

//Function to print the students' information.
void Student::printInfo()
{
     cout << "Name: " << name << endl;
     cout << "Age: " << age << endl;
     cout << "GPA: " << gpa << endl;
}

//Destructor.
Student::~Student()
{

}

/************************************************************************************************************
**Program Title: Doubly Linked Lists
**Author: Kevin J. Ohrlund
**Date: 13 May 2018
**Description: Header file for the List class. Defines the Node struct and functions for the program.
*************************************************************************************************************/

#ifndef LIST_HPP
#define LIST_HPP
#include <cstdlib>
#include <limits>

class List
{
protected:
	//****Note: Assignment specified there be a separate class for the Node. Per discussion with Harlan, we could use just a Struct for this assignment.
	struct Node 
	{
		int val;
		Node *next;
		Node *prev;

		Node(int val)
		{
			this->val = val;
		}
	};
	Node *head;
	Node *tail;
	int gameChoice;

public:
	List();
	void addBeginning(int val);
	void addEnd(int val);
	void deleteBeginning();
	void deleteEnd();
	void traverseBackward();
	void traverseForward();
	void run();
	int validate(int x, int y);
};

#endif
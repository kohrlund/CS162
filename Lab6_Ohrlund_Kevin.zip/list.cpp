/************************************************************************************************************
**Program Title: Doubly Linked Lists
**Author: Kevin J. Ohrlund
**Date: 13 May 2018
**Description: Implementation file for the List class. Defines all the functions that run the program.
*************************************************************************************************************/

#include "list.hpp"
#include <iostream>

using std::cin;
using std::cout;
using std::endl;

//Default constructor for the head and tail.
List::List()
{
	head = nullptr;
	tail = nullptr;
}

//Runs the menu.
void List::run()
{
	cout << "Welcome to doubly linked lists!" << endl;
	cout << "Programmed by Kevin J. Ohrlund." << endl << endl;

	cout << "Enter your choice below:" << endl;
	cout << "1. Add a new node to the head." << endl;
	cout << "2. Add a new node to the tail." << endl;
	cout << "3. Delete the first node in the list." << endl;
	cout << "4. Delete the last node in the list." << endl;
	cout << "5. Traverse the list reversely." << endl;
	cout << "6. Exit." << endl;

	gameChoice = validate(1, 6);

	//While the user chooses to continue... Route them through the appropriate functions.
	while (gameChoice != 6)
	{
		if (gameChoice == 1)
		{
			cout << "Enter the number you would like to add to this node: ";
			int tempNum = validate(-10000, 10000);
			addBeginning(tempNum);
			traverseForward();
		}

		else if (gameChoice == 2)
		{
			cout << "Enter the number you would like to add to this node: ";
			int tempNum = validate(-1000000000, 1000000000);
			addEnd(tempNum);
			traverseForward();
		}

		else if (gameChoice == 3)
		{
			deleteBeginning();
		}

		else if (gameChoice == 4)
		{
			deleteEnd();
		}

		else if (gameChoice == 5)
		{
			traverseBackward();
		}

		//Prompt the user to play again.
		cout << "\n\nEnter your choice below:" << endl;
		cout << "1. Add a new node to the head." << endl;
		cout << "2. Add a new node to the tail." << endl;
		cout << "3. Delete the first node in the list." << endl;
		cout << "4. Delete the last node in the list." << endl;
		cout << "5. Traverse the list reversely." << endl;
		cout << "6. Exit." << endl;

		gameChoice = validate(1, 6);
	}

}

//Adds an integer to the end of the list.
void List::addEnd(int val)
{
	Node *temp = new Node(val);

	if (head == nullptr)
	{
		head = temp;
		tail = temp;
	}

	else
	{
		tail->next = temp;
		temp->prev = tail;
		tail = temp;
	}
}

//Adds an integer to the beginning of the list.
void List::addBeginning(int val)
{
	Node *temp = new Node(val);
	if (head == nullptr)
	{
		head = temp;
		tail = temp;
	}

	else
	{
		head->prev = temp;
		temp->next = head;
		head = temp;
	}
}

//Deletes the integer at the beginning of the list.
void List::deleteBeginning()
{
	if (head == nullptr)
	{
		cout << "Your list is empty!" << endl;
	}

	else
	{
		Node *nodePtr = head;
		head = head->next;
		delete nodePtr;
	}

	traverseForward();
}

//Deletes the integer at the end of the list.
void List::deleteEnd()
{
	if (head == nullptr)
	{
		cout << "Your list is empty!" << endl;
	}

	else
	{
		Node *nodePtr = tail;
		tail = tail->prev;
		if (tail == NULL)
		{
			head = NULL;
		}

		else
		{
			tail->next = NULL;
			delete nodePtr;
		}
	}
	traverseForward();
}

//Prints the list backwards.
void List::traverseBackward()
{
	if (head == nullptr)
	{
		cout << "Your list is empty!" << endl;
	}

	else
	{
		Node *nodePtr = tail;
		while (nodePtr)
		{
			cout << nodePtr->val << " ";
			nodePtr = nodePtr->prev;
		}
	}
}

//Prints the list forward.
void List::traverseForward()
{
	if (head != nullptr)
	{
		cout << "Your node forward: ";
		Node *nodePtr = head;
		while (nodePtr)
		{
			cout << nodePtr->val << " ";
			nodePtr = nodePtr->next;
		}
	}
}

//Helper function to validate user data.
int List::validate(int x, int y)
{
	int z = 0;
	cin >> z;

	while (cin.fail() || z < x || z > y)
	{
		cout << "Invalid entry. Enter a number from " << x << " to " << y << '.' << endl;
		cin.clear();
		cin.ignore(std::numeric_limits<int>::max(), '\n');

		cin >> z;
	}

	return z;
}
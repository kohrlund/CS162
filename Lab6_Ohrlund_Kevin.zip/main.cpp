/************************************************************************************************************
**Program Title: Doubly Linked Lists
**Author: Kevin J. Ohrlund
**Date: 13 May 2018
**Description: Main file for the program. Instantiates a List object and begins the program.
*************************************************************************************************************/

#include "list.hpp"

int main()
{
	List l1;
	l1.run();

	return 0;
}
/***************************************************************************************************************
**Program Name: War Dice
**Author: Kevin J. Ohrlund
**Date: 21 April 2018
**Description: Header file for game.cpp
****************************************************************************************************************/
#ifndef GAME_HPP
#define GAME_HPP

class Game
{
public:
     void playGame(int* menuArray);
     void startMenu();

private:
     int p1Score;
     int p2Score;
     int turnNumber;
     int p1Roll;
     int p2Roll;

};

#endif

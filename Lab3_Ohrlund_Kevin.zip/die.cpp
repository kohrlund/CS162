/***************************************************************************************************************
**Program Name: War Dice
**Author: Kevin J. Ohrlund
**Date: 21 April 2018
**Description: Implementation file for the die class. Contains the function that rolls a standard die.
****************************************************************************************************************/
#include "die.hpp"
#include <ctime>
#include <cstdlib>

int Die::rollDie(int numSides)
{
     //Takes a random number mod number of sides +1 to simulate dice rolling.
     rollResult = 0;
     rollResult = (rand() % numSides + 1);
     return rollResult;
}

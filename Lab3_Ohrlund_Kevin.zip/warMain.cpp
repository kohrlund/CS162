/***************************************************************************************************************
**Program Name: War Dice
**Author: Kevin J. Ohrlund
**Date: 21 April 2018
**Description: Main file for the program. Calls the start menu.
****************************************************************************************************************/
#include <iostream>
#include <cstdlib>
#include <ctime>

#include "die.hpp"
#include "loadedDie.hpp"
#include "game.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;

int main()
{
     srand(time(0));//Seeded rand() for the whole program.

     Game g1;

     //Call the start menu.
     g1.startMenu();
     return 0;
}

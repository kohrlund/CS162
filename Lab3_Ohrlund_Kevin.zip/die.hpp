#/***************************************************************************************************************
**Program Name: War Dice
**Author: Kevin J. Ohrlund
**Date: 21 April 2018
**Description: Header file for the die class.
****************************************************************************************************************/
#ifndef DIE_HPP
#define DIE_HPP

class Die

{
public:
     Die()
     {
          numSides = 0;
          rollResult = 0;
     }

     virtual int rollDie(int);

     ~Die(){}

protected:
     int rollResult;
     int numSides;
};


#endif

/***************************************************************************************************************
**Program Name: War Dice
**Author: Kevin J. Ohrlund
**Date: 21 April 2018
**Description: Runs the game and implements the game class.
****************************************************************************************************************/
#include "game.hpp"
#include "die.hpp"
#include "loadedDie.hpp"

#include <iostream>
#include <limits>

using std::cout;
using std::cin;
using std::endl;

void Game::startMenu()
{
     //Initialize all variables.
     int numTurns = 0, numSides1 = 0, numSides2 = 0, isLoaded1 = 0, isLoaded2 = 0, gameChoice = 0;
     int* menuArray = new int[5];

     //Display the welcome message.
     cout << "Welcome to the dice war game!" << endl;
     cout << "Author: Kevin J. Ohrlund" << endl;

     //Prompt the user if they want to play or exit.
     cout << "\n\nEnter your choice below:" << endl;
     cout << "1. Play Game." << endl;
     cout << "2. Exit." << endl;
     cin >> gameChoice;

     while (cin.fail() || (!(gameChoice == 1 || gameChoice == 2)))
     {
          cout << "Invalid entry. Enter 1 to play the game or 2 to exit." << endl;
          cin.clear();
          cin.ignore(std::numeric_limits<int>::max(), '\n');
          cin >> gameChoice;
     }
     cout << endl;

     //While the user chooses to continue playing...
     while (gameChoice == 1)
     {
          //Reset all options to 0.
          for (int i = 0; i < 5; i++)
          {
               menuArray[i] = 0;
          }

          //Get the number of turns for the game.
          cout << "How many turns will this game run?" << endl;
          cin >> numTurns;

          while (cin.fail())
          {
               cout << "Invalid entry. Enter a number greater than 0." << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<int>::max(), '\n');
               cin >> numTurns;
          }
          cout << endl;
          menuArray[0] = numTurns;

          //Get the choice for die for player 1.
          cout << "\nEnter your die choice below for Player 1:" << endl;
          cout << "1. Standard die." << endl;
          cout << "2. Loaded die." << endl;

          cin >> isLoaded1;

          while (cin.fail() || (!(isLoaded1 == 1 || isLoaded1 == 2)))
          {
               cout << "Invalid entry. Enter 1 for standard die or 2 for loaded." << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<int>::max(), '\n');
               cin >> isLoaded1;
          }
          cout << endl;
          menuArray[1] = isLoaded1;

          //Get the choice for die for player 2.
          cout << "\nEnter your die choice below for Player 2:" << endl;
          cout << "1. Standard die." << endl;
          cout << "2. Loaded die." << endl;

          cin >> isLoaded2;

          while (cin.fail() || (!(isLoaded2 == 1 || isLoaded2 == 2)))
          {
               cout << "Invalid entry. Enter 1 for standard die or 2 for loaded." << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<int>::max(), '\n');
               cin >> isLoaded2;
          }
          cout << endl;
          menuArray[2] = isLoaded2;

          //Get the number of die sides for player 1.
          cout << "\nHow many sides will player 1's die contain?" << endl;
          cin >> numSides1;

          while (cin.fail() || numSides1 < 4 || numSides1 > 20)
          {
               cout << "Invalid entry. Enter a number 4-20" << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<int>::max(), '\n');
               cin >> numSides1;
          }
          cout << endl;
          menuArray[3] = numSides1;

          //Get the number of sides for player 2.
          cout << "\nHow many sides will player 2's die contain?" << endl;
          cin >> numSides2;

          while (cin.fail() || numSides2 < 4 || numSides2 > 20)
          {
               cout << "Invalid entry. Enter a number 4-20" << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<int>::max(), '\n');
               cin >> numSides2;
          }
          cout << endl;
          menuArray[4] = numSides2;

          //Call a game object and run the simulation.
          Game g1;
          g1.playGame(menuArray);

          //Ask if the user will play again.
          cout << endl;
          cout << "Would you like to play again? Enter your choice below:" << endl;
          cout << "1. Play again." << endl;
          cout << "2. Quit." << endl;
          cin >> gameChoice;

          while (cin.fail() || (!(gameChoice == 1 || gameChoice == 2)))
          {
               cout << "Invalid entry. Enter 1 to play the game or 2 to exit." << endl;
               cin.clear();
               cin.ignore(std::numeric_limits<int>::max(), '\n');
               cin >> gameChoice;
          }
          cout << endl;
     }
     //Free the memory.
     delete[] menuArray;
}

//playGame function runs the whole game.
void Game::playGame(int* menuArray)
{
     //Initialize all variables, the regular die object and a loaded die object.
     turnNumber = 1, p1Score = 0, p2Score = 0;
     Die d1;
     LoadedDie d2;

     //While there are turns remaining...
     while (turnNumber < menuArray[0]+1)
     {
          cout << "Turn #" << turnNumber << ':' << endl;

          //If the player chose a normal die, roll standard. Otherwise roll the loaded die.
          if (menuArray[1] == 1)
          {
               p1Roll = d1.rollDie(menuArray[3]);
          }

          else
          {
               p1Roll = d2.rollDie(menuArray[3]);
          }

          //Tell the user what player 1 rolled.
          cout << "Player 1 rolled a " << p1Roll << " from their " << menuArray[3] <<'-' << "sided die." << endl;

          //If the player chose a normal die, roll standard. Otherwise roll the loaded die.
          if (menuArray[2] == 1)
          {
               p2Roll = d1.rollDie(menuArray[4]);
          }

          else
          {
               p2Roll = d2.rollDie(menuArray[4]);
          }

          //Tell the user what player 2 rolled.
          cout << "Player 2 rolled a " << p2Roll << " from their " << menuArray[4] << '-' << "sided die." << endl;

          //Determine which player won the round.
          if (p1Roll > p2Roll)
          {
               cout << "Player 1 wins the round!" << endl;
               p1Score++;
          }

          else if (p2Roll > p1Roll)
          {
               cout << "Player 2 wins the round!" << endl;
               p2Score++;;
          }

          else
          {
               cout << "This round is a draw!" << endl;
          }

          //Display the score.
          cout << "Current score is: " << p1Score << '-' << p2Score << '.' << endl;
          cout << endl;

          //Update the turn variable.
          turnNumber++;
     }

     //Determine the winner of the game.
     if (p1Score > p2Score)
     {
          cout << "Player 1 wins the game by a score of " << p1Score << '-' << p2Score << '.'<< endl;
     }

     else if (p2Score > p1Score)
     {
          cout << "Player 2 wins the game by a score of " << p2Score << '-' << p1Score << '.' << endl;
     }

     else
     {
          cout << "This game is a draw with a score of " << p1Score << '-' << p2Score << '.' << endl;
     }

}

/***************************************************************************************************************
**Program Name: War Dice
**Author: Kevin J. Ohrlund
**Date: 21 April 2018
**Description: Header file for the loaded die class.
****************************************************************************************************************/
#ifndef LOADEDDIE_HPP
#define LOADEDDIE_HPP

#include "die.hpp"

//Inherits the public and protected member variables and functions of the die class.
class LoadedDie : public Die

{
public:
     int rollDie(int);

protected:

private:
};

#endif

/***************************************************************************************************************
**Program Name: War Dice
**Author: Kevin J. Ohrlund
**Date: 21 April 2018
**Description: Implementation file for the loaded die class. Contains the function that rolls a loaded die.
****************************************************************************************************************/
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>

#include "loadedDie.hpp"
#include "die.hpp"

using std::vector;

//Loaded die roll. Uses a vector to double the instances of the upper numbers.
int LoadedDie::rollDie(int numSides)
{
     //Create the vector and add numbers 1-i specified by the user.
     vector<int> dieVector;
     for (int i = 1; i < numSides+1; i++)
     {
          dieVector.push_back(i);
     }

     //Add the upper 50% of the numbers to the end of the vector.
     for (int j = ((numSides / 2) + 1); j <= numSides; j++)
     {
          dieVector.push_back(j);
     }

     //Get a random member of the vector.
     rollResult = (dieVector[rand() % dieVector.size()]);

     //Return the roll.
     return rollResult;
}

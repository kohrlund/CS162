/************************************************************************************************
*Program Name: Circular Linked List
**Author: Kevin J. Ohrlund
**Date: 20 May 2018
**Description: Main file instantiates a menu object and calls the run function.
*************************************************************************************************/

#include "menu.hpp"

int main()
{
	Menu m1;
	m1.run();
	return 0;
}
/******************************************************************************************************************************************
*Program Name: Circular Linked List
**Author: Kevin J. Ohrlund
**Date: 20 May 2018
**Description: Header file for the queue class. Defines the queue functions that run the program and defines the QueueNode struct.
*******************************************************************************************************************************************/

#ifndef QUEUE_HPP
#define QUEUE_HPP

class Queue
{
public:
	Queue();
	~Queue();
	bool isEmpty();
	void addBack(int val);
	int getFront();
	void removeFront();
	void printQueue();

protected:
	struct QueueNode
	{
		int val;
		QueueNode *next;
		QueueNode *prev;

		QueueNode(int val)
		{
			this->val = val;
		}
	};

	QueueNode *head;
};

#endif
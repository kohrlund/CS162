/**********************************************************************************************************************************
*Program Name: Circular Linked List
**Author: Kevin J. Ohrlund
**Date: 20 May 2018
**Description: Header file for the menu class. Defines the functions that control the menu.
***********************************************************************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

class Menu
{
public:
	Menu();
	~Menu();
	void run();
	int validate(int x, int y);
	
private:
	int menuChoice;
};

#endif
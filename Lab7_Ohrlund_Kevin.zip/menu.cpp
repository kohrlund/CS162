/**********************************************************************************************************************************
*Program Name: Circular Linked List
**Author: Kevin J. Ohrlund
**Date: 20 May 2018
**Description: Implementation file for the menu class. Controls the flow of the menu options and calls the queue class functions.
***********************************************************************************************************************************/

#include "menu.hpp"
#include "queue.hpp"
#include <iostream>
#include <limits>
using std::cin;
using std::cout;
using std::endl;

//Constructor for the menu object.
Menu::Menu()
{
	menuChoice = 1;
}

//Destructor for the menu object.
Menu::~Menu()
{

}

//Controls the menu options. Receives nothing and returns nothing.
void Menu::run()
{
	//Greet the user and present the menu options.
	cout << "Welcome to my Queue!" << endl;
	cout << "Programmed by Kevin J. Ohrlund" << endl << endl;

	cout << "Choose from the following options:" << endl;
	cout << "1. Enter a value to be added to the back of the queue." << endl;
	cout << "2. Display the first node (front) value." << endl;
	cout << "3. Remove the first node (front) value." << endl;
	cout << "4. Display the queue contents." << endl;
	cout << "5. Exit." << endl;

	//Validate their choice and instantiate the queue object.
	menuChoice = validate(1, 5);
	Queue q1;

	//While the user continues to manipulate the queue...
	while (menuChoice != 5)
	{
		//If they choose to enter a number to the front...
		if (menuChoice == 1)
		{
			//Validate the number and send to addBack function.
			cout << "\nEnter the number you would like to add to the end of the Queue: ";
			menuChoice = validate(-100000, 100000);
			q1.addBack(menuChoice);
		}

		//If they choose to print the first value of the queue...
		else if (menuChoice == 2)
		{
			//Display if the queue is empty.
			if (q1.isEmpty() == true)
			{
				cout << "Your queue is empty!" << endl;
			}

			//Else get the first value from the getFront function.
			else
			{
				cout << "Your first value is: " << q1.getFront();
			}
		}

		//If the user chooses to delete the first number of the queue...
		else if (menuChoice == 3)
		{
			//Display that the queue is empty.
			if (q1.isEmpty() == true)
			{
				cout << "Your queue is empty!" << endl;
			}

			//Else call the removeFront function.
			else
			{
				q1.removeFront();
			}
		}

		//If the user chooses to print the queue...
		else
		{
			//Display that the queue is empty.
			if (q1.isEmpty() == true)
			{
				cout << "Your queue is empty!" << endl;
			}

			//Else call the printQueue function.
			else
			{
				q1.printQueue();
			}
		}

		//Display the menu options for the user.
		cout << "\n\nChoose from the following options:" << endl;
		cout << "1. Enter a value to be added to the back of the queue." << endl;
		cout << "2. Display the first node (front) value." << endl;
		cout << "3. Remove the first node (front) value." << endl;
		cout << "4. Display the queue contents." << endl;
		cout << "5. Exit." << endl;

		menuChoice = validate(1, 5);
	}
}

//Helper function to validate user's input.
int Menu::validate(int x, int y)
{
	int z = 0;
	cin >> z;

	while (cin.fail() || z < x || z > y)
	{
		cout << "Invalid entry. Enter a number from " << x << " to " << y << '.' << endl;
		cin.clear();
		cin.ignore(std::numeric_limits<int>::max(), '\n');

		cin >> z;
	}

	return z;
}
/**********************************************************************************************************************************
*Program Name: Circular Linked List
**Author: Kevin J. Ohrlund
**Date: 20 May 2018
**Description: Implementation file for the queue class. Controls the functions that drive the menu options.
***********************************************************************************************************************************/

#include "queue.hpp"
#include <iostream>

using std::cout;
using std::endl;

//Default constructor sets head and nodePtr to null pointers.
Queue::Queue()
{
	head = nullptr;
}

//Receives nothing and returns t/f.
bool Queue::isEmpty()
{
	//If the head is a null pointer (empty), return true.
	if (head == nullptr)
	{
		return true;
	}
	
	//Else return false (indicating there are objects in the queue).
	else
	{
		return false;
	}
}

//Receives an int. Returns nothing. Adds the integer (as a new QueueNode) to the end of the queue.
void Queue::addBack(int val)
{
	//If it is the first object in the queue...
	if (head == nullptr)
	{
		//Create a new QueueNode with the value and set the previous and next pointers back to the head.
		QueueNode *temp = new QueueNode(val);
		head = temp;
		head->next = head;
		head->prev = head;
	}

	//Else if there are already objects in the queue...
	else
	{
		//Set the head previous pointer to the node pointer and create a new QueueNode.
		QueueNode *nodePtr = head->prev;
		QueueNode *temp = new QueueNode(val);

		//Set the new QueueNode's next pointer to the head and the previous to the old previous.
		temp->prev = nodePtr;
		temp->next = head;

		//Set the old last object's next pointer to the new last object, and set the head's prev pointer to the new last object.
		nodePtr->next = temp;
		head->prev = temp;
	}
}

//Receives nothing and returns the value stored at the head pointer node.
int Queue::getFront()
{
	return head->val;
}

//Receives nothing and returns nothing. Removes the front node of the queue.
void Queue::removeFront()
{
	//If there is only one object in the queue...
	if (head == head->next)
	{
		//Delete the head and set the head pointer to a null pointer.
		delete head;
		head = nullptr;
	}

	//If there are multiple objects in the queue...
	else
	{
		//Set the head to the head's next pointer and re-link the nodes of the queue.
		QueueNode *nodePtr = head;
		head = head->next;
		head->prev = nodePtr->prev;
		head->prev->next = head;

		//Delete what was previously the head node.
		delete nodePtr;
	}
}

//Receives nothing and returns nothing. Prints the queue from start to finish.
void Queue::printQueue()
{
	//While the next pointer is not the head, display the value.
	cout << "The full queue is: ";
	QueueNode *nodePtr = head;
	while (nodePtr->next != head)
	{
		cout << nodePtr->val << " ";
		nodePtr = nodePtr->next;
	}

	//Display the final value.
	cout << nodePtr->val << endl;
}

//Destructor for the Queue object. Deletes all memory by calling the removeFront function until isEmpty returns true.
Queue::~Queue()
{
	while (isEmpty() == false)
	{
		removeFront();
	}
}